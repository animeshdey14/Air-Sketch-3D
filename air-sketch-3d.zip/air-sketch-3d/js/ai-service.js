/**
 * Designed by Animesh_D
 * AIService - Modular 3D Generation Architecture.
 * Combines in-browser procedural generation, direct sketch-to-mesh extrusion,
 * and an extensible adapter for external AI 3D APIs (e.g. Meshy, Tripo3D).
 */
import { Procedural3D } from './procedural-3d.js';
import { ShapeExtruder } from './shape-extruder.js';

export class AIService {
  constructor() {
    this.mode = localStorage.getItem('air_sketch_ai_mode') || 'hybrid'; // 'hybrid', 'procedural', 'extrude', 'external_api'
    this.apiKey = localStorage.getItem('air_sketch_api_key') || '';
    this.apiEndpoint = localStorage.getItem('air_sketch_api_endpoint') || 'https://api.meshy.ai/v2/text-to-3d';
  }

  setMode(mode) {
    this.mode = mode;
    localStorage.setItem('air_sketch_ai_mode', mode);
  }

  setApiCredentials(key, endpoint) {
    this.apiKey = key;
    this.apiEndpoint = endpoint;
    localStorage.setItem('air_sketch_api_key', key);
    localStorage.setItem('air_sketch_api_endpoint', endpoint);
  }

  /**
   * Main generation entry point
   * @param {string} promptText - User's spoken or typed description
   * @param {object} strokeData - Extracted strokes & bounding box from canvas
   * @returns {Promise<{ meshGroup: THREE.Group, meta: object }>}
   */
  async generate3D(promptText, strokeData) {
    const startTime = performance.now();

    // 1. External AI API mode if user configured API credentials
    if (this.mode === 'external_api' && this.apiKey) {
      try {
        const externalResult = await this._callExternalAI(promptText, strokeData);
        if (externalResult) return externalResult;
      } catch (err) {
        console.warn('External AI API failed, falling back to local hybrid generator:', err);
      }
    }

    // 2. Direct Stroke Extrusion Mode
    if (this.mode === 'extrude') {
      const meshGroup = ShapeExtruder.generateFromStrokes(strokeData);
      const elapsed = Math.round(performance.now() - startTime);
      return {
        meshGroup,
        meta: {
          title: promptText || 'Custom Mid-Air Sketch',
          type: 'Extruded Air-Drawing',
          generationTimeMs: elapsed,
          source: 'In-Browser Stroke Extrusion Engine'
        }
      };
    }

    // 3. Hybrid Mode (Default): Smart object synthesis
    // Checks if prompt matches a rich procedural archetype
    const proceduralMesh = Procedural3D.createModel(promptText, strokeData);
    let finalMesh = proceduralMesh;
    let modelType = 'Procedural Semantic Synthesis';

    // If description mentions "lathe", "turned", or is empty, try stroke extrusion
    if (!promptText && strokeData && strokeData.strokes.length > 0) {
      finalMesh = ShapeExtruder.generateFromStrokes(strokeData);
      modelType = 'Air-Drawing Geometry';
    }

    const elapsed = Math.round(performance.now() - startTime);

    return {
      meshGroup: finalMesh,
      meta: {
        title: promptText ? `3D: ${promptText}` : 'Air Sketch 3D Model',
        type: modelType,
        prompt: promptText,
        strokeCount: strokeData ? strokeData.strokes.length : 0,
        generationTimeMs: elapsed,
        source: 'Instant In-Browser 3D Engine'
      }
    };
  }

  async _callExternalAI(promptText, strokeData) {
    // Architecture ready for AI 3D services like Meshy.ai or Tripo3D
    const response = await fetch(this.apiEndpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mode: 'preview',
        prompt: promptText,
        art_style: 'cyberpunk'
      })
    });

    if (!response.ok) {
      throw new Error(`AI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('External AI task initiated:', data);
    return null; // Will fallback gracefully to procedural while task polls
  }
}
