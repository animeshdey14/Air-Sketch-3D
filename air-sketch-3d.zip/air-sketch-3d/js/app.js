/**
 * Designed by Animesh_D
 * App - Master controller and state machine for Air Sketch 3D
 */
import { AudioFX } from './audio-fx.js?v=5';
import { CameraManager } from './camera.js?v=5';
import { HandTracker } from './hand-tracker.js?v=5';
import { CanvasDrawer } from './canvas-drawer.js?v=5';
import { SpeechInput } from './speech-input.js?v=5';
import { AIService } from './ai-service.js?v=5';
import { ThreeScene } from './three-scene.js?v=5';
import { ModelExporter } from './exporter.js?v=5';

export class App {
  constructor() {
    this.state = 'INITIALIZING'; // 'INITIALIZING', 'ONBOARDING', 'DRAWING', 'PROMPTING', 'VIEWING_3D'

    // DOM Elements
    this.dom = {
      video: document.getElementById('camera-feed'),
      hudCanvas: document.getElementById('hud-canvas'),
      drawCanvas: document.getElementById('draw-canvas'),
      threeCanvas: document.getElementById('three-canvas'),

      // UI Overlays & Panels
      welcomeModal: document.getElementById('welcome-modal'),
      promptModal: document.getElementById('prompt-modal'),
      settingsModal: document.getElementById('settings-modal'),
      drawingToolbar: document.getElementById('drawing-toolbar'),
      inspectToolbar: document.getElementById('inspect-toolbar'),
      statusBadge: document.getElementById('status-badge'),
      statusText: document.getElementById('status-text'),
      pinchMeter: document.getElementById('pinch-meter'),
      pinchMeterFill: document.getElementById('pinch-meter-fill'),
      strokeCounter: document.getElementById('stroke-counter'),
      modelInfoCard: document.getElementById('model-info-card'),
      modelTitle: document.getElementById('model-title'),
      modelMeta: document.getElementById('model-meta'),

      // Action Buttons
      btnStartAirCanvas: document.getElementById('btn-start-canvas'),
      btnFlipCamera: document.getElementById('btn-flip-camera'),
      btnToggleAudio: document.getElementById('btn-toggle-audio'),
      btnUndo: document.getElementById('btn-undo'),
      btnClear: document.getElementById('btn-clear') || document.getElementById('btnClear'),
      btnFinishSketch: document.getElementById('btn-finish-sketch'),
      btnBackToDraw: document.getElementById('btn-back-to-draw'),
      btnMaterialize: document.getElementById('btn-materialize'),
      btnVoiceInput: document.getElementById('btn-voice-input'),
      btnNewSketch: document.getElementById('btn-new-sketch'),
      btnRegenerate: document.getElementById('btn-regenerate'),
      btnExportObj: document.getElementById('btn-export-obj'),
      btnToggleWireframe: document.getElementById('btn-toggle-wireframe'),
      btnToggleRotate: document.getElementById('btn-toggle-rotate'),
      btnResetView: document.getElementById('btn-reset-view'),
      btnSettings: document.getElementById('btn-settings'),
      btnCloseSettings: document.getElementById('btn-close-settings'),
      btnSaveSettings: document.getElementById('btn-save-settings'),

      // Inputs & Preview
      sketchPreviewImg: document.getElementById('sketch-preview-img'),
      objectPromptInput: document.getElementById('object-prompt-input'),
      voiceStatusIndicator: document.getElementById('voice-status-indicator'),
      quickTagsContainer: document.getElementById('quick-tags-container'),
      paletteContainer: document.getElementById('color-palette'),
      threeColorPalette: document.getElementById('three-color-palette'),
      brushSizeSlider: document.getElementById('brush-size-slider'),

      // Settings fields
      generationModeSelect: document.getElementById('setting-generation-mode'),
      apiKeyInput: document.getElementById('setting-api-key'),

      // 3D Synthesis Progress & Time Frame
      renderProgressModal: document.getElementById('render-progress-modal'),
      renderProgressTitle: document.getElementById('render-progress-title'),
      renderProgressPhase: document.getElementById('render-progress-phase'),
      renderTimerText: document.getElementById('render-timer-text'),
      renderProgressBar: document.getElementById('render-progress-bar')
    };

    // Submodules
    this.audio = new AudioFX();
    this.camera = null;
    this.tracker = null;
    this.drawer = null;
    this.speech = null;
    this.aiService = new AIService();
    this.threeScene = null;

    // Data Cache
    this.lastStrokeData = null;
    this.currentModelGroup = null;

    this._init();
  }

  async _init() {
    this._syncCanvasSizes();
    window.addEventListener('resize', () => this._syncCanvasSizes());

    // Initialize Drawing Engine
    this.drawer = new CanvasDrawer(this.dom.drawCanvas, {
      audio: this.audio,
      onStrokeCountChange: (count) => this._onStrokeCountChange(count)
    });

    // Initialize 3D Viewport
    this.threeScene = new ThreeScene(this.dom.threeCanvas, {
      audio: this.audio
    });

    // Initialize Speech Recognition
    this.speech = new SpeechInput({
      onStart: () => {
        this.dom.btnVoiceInput.classList.add('listening');
        this.dom.voiceStatusIndicator.textContent = 'Listening... Speak now!';
        this.dom.voiceStatusIndicator.classList.add('active');
        this.audio.playClick();
      },
      onResult: (transcript, isFinal) => {
        this.dom.objectPromptInput.value = transcript;
        this.dom.voiceStatusIndicator.textContent = `Heard: "${transcript}"`;
        if (isFinal) {
          this.audio.playPinchEnd();
        }
      },
      onEnd: () => {
        this.dom.btnVoiceInput.classList.remove('listening');
        this.dom.voiceStatusIndicator.classList.remove('active');
      },
      onError: (msg) => {
        this.dom.voiceStatusIndicator.textContent = msg;
        this.dom.btnVoiceInput.classList.remove('listening');
      }
    });

    // Populate Quick Suggestion Tags
    this._populateQuickTags();

    // Setup UI Event Handlers
    this._bindEvents();

    // Set Initial State
    this._setState('ONBOARDING');
  }

  _syncCanvasSizes() {
    const width = window.innerWidth;
    const height = window.innerHeight;

    [this.dom.hudCanvas, this.dom.drawCanvas, this.dom.threeCanvas].forEach((cnv) => {
      if (cnv) {
        cnv.width = width;
        cnv.height = height;
      }
    });

    if (this.threeScene) {
      this.threeScene.resize(width, height);
    }
    if (this.drawer) {
      this.drawer.resize();
    }
  }

  _bindEvents() {
    // 1. Onboarding launch button
    const on = (el, evt, fn) => {
      if (el) el.addEventListener(evt, fn);
    };

    // 1. Onboarding launch button
    on(this.dom.btnStartAirCanvas, 'click', async () => {
      this.audio.playClick();
      await this._startCameraAndTracker();
    });

    // 2. Camera flip button
    on(this.dom.btnFlipCamera, 'click', async () => {
      this.audio.playClick();
      if (this.camera) {
        const mode = await this.camera.toggleFacingMode();
        if (this.tracker) {
          this.tracker.setFrontFacing(this.camera.isFrontFacing());
        }
        this._updateStatus(`Switched to ${mode === 'user' ? 'Front' : 'Back'} Camera`);
      }
    });

    // 3. Audio toggle
    on(this.dom.btnToggleAudio, 'click', () => {
      const isMuted = this.audio.toggleMute();
      if (this.dom.btnToggleAudio) {
        this.dom.btnToggleAudio.innerHTML = isMuted ? '🔇' : '🔊';
        this.dom.btnToggleAudio.classList.toggle('active', !isMuted);
      }
    });

    // 4. Undo and Clear
    on(this.dom.btnUndo, 'click', () => {
      if (this.drawer) this.drawer.undo();
    });

    on(this.dom.btnClear, 'click', () => {
      if (this.drawer) this.drawer.clear();
    });

    // 5. Palette color selection
    if (this.dom.paletteContainer) {
      this.dom.paletteContainer.querySelectorAll('.color-swatch').forEach((swatch) => {
        swatch.addEventListener('click', (e) => {
          this.audio.playClick();
          const color = e.target.getAttribute('data-color');
          this.drawer.setColor(color);
          this.dom.paletteContainer.querySelectorAll('.color-swatch').forEach((s) => s.classList.remove('selected'));
          e.target.classList.add('selected');
        });
      });
    }

    // 6. Brush Size Slider
    on(this.dom.brushSizeSlider, 'input', (e) => {
      if (this.drawer) this.drawer.setLineWidth(parseInt(e.target.value, 10));
    });

    // 7. Finish Sketch -> Prompt Modal
    on(this.dom.btnFinishSketch, 'click', () => {
      this.audio.playClick();
      this._openPromptModal();
    });

    // 8. Back to Draw
    on(this.dom.btnBackToDraw, 'click', () => {
      this.audio.playClick();
      this._setState('DRAWING');
    });

    // 9. Voice input toggle button
    on(this.dom.btnVoiceInput, 'click', () => {
      this.audio.init();
      if (this.speech) this.speech.start();
    });

    // 10. Materialize in 3D button
    on(this.dom.btnMaterialize, 'click', async () => {
      this.audio.playClick();
      await this._materializeModel();
    });

    // 11. 3D Viewport Controls
    on(this.dom.btnToggleWireframe, 'click', () => {
      this.audio.playClick();
      const mode = this.threeScene.cycleMaterialMode();
      this._updateStatus(`✨ Hologram Mode: ${mode}`, 'active');
      if (this.dom.btnToggleWireframe) {
        this.dom.btnToggleWireframe.innerHTML = `<span>🌐</span> ${mode}`;
      }
    });

    on(this.dom.btnToggleRotate, 'click', () => {
      this.audio.playClick();
      const isRot = this.threeScene.toggleAutoRotate();
      if (this.dom.btnToggleRotate) this.dom.btnToggleRotate.classList.toggle('active', isRot);
    });

    on(this.dom.btnResetView, 'click', () => {
      this.audio.playClick();
      this.threeScene.resetView();
    });

    on(this.dom.btnExportObj, 'click', () => {
      this.audio.playClick();
      if (this.currentModelGroup) {
        const title = (this.dom.objectPromptInput.value || 'air-sketch').toLowerCase().replace(/\s+/g, '-');
        ModelExporter.exportToOBJ(this.currentModelGroup, `${title}-3d.obj`);
        this._updateStatus('Downloaded 3D .OBJ file!');
      }
    });

    on(this.dom.btnRegenerate, 'click', () => {
      this.audio.playClick();
      this._openPromptModal();
    });

    on(this.dom.btnNewSketch, 'click', () => {
      this.audio.playClick();
      if (this.drawer) this.drawer.clear();
      this._setState('DRAWING');
    });

    // 3D Color Palette
    if (this.dom.threeColorPalette) {
      this.dom.threeColorPalette.querySelectorAll('.color-swatch').forEach((swatch) => {
        swatch.addEventListener('click', (e) => {
          this.audio.playClick();
          const color = e.target.getAttribute('data-color');
          this.threeScene.changeModelColor(color);
          this.dom.threeColorPalette.querySelectorAll('.color-swatch').forEach((s) => s.classList.remove('selected'));
          e.target.classList.add('selected');
        });
      });
    }

    // Settings Modal
    on(this.dom.btnSettings, 'click', () => {
      this.audio.playClick();
      this.dom.generationModeSelect.value = this.aiService.mode;
      this.dom.apiKeyInput.value = this.aiService.apiKey;
      this.dom.settingsModal.classList.remove('hidden');
    });

    on(this.dom.btnCloseSettings, 'click', () => {
      this.audio.playClick();
      this.dom.settingsModal.classList.add('hidden');
    });

    on(this.dom.btnSaveSettings, 'click', () => {
      this.audio.playClick();
      this.aiService.setMode(this.dom.generationModeSelect.value);
      this.aiService.setApiCredentials(this.dom.apiKeyInput.value, this.aiService.apiEndpoint);
      this.dom.settingsModal.classList.add('hidden');
      this._updateStatus('Settings saved');
    });
  }

  async _startCameraAndTracker() {
    this._setState('DRAWING');
    this._updateStatus('Requesting camera access...', 'ready');

    this.camera = new CameraManager(this.dom.video, {
      facingMode: 'user',
      onError: (friendlyErr) => {
        this._updateStatus(friendlyErr.message || 'Camera error. You can still sketch with touch/mouse!', 'ready');
      }
    });

    try {
      await this.camera.start();
      this._updateStatus('Camera active. Loading AI hand tracker...', 'active');
    } catch (camErr) {
      console.warn('Camera failed:', camErr);
      this._updateStatus('Camera unavailable. You can draw with your finger or mouse!', 'ready');
    }

    // Initialize Hand Tracker in parallel / background
    this.tracker = new HandTracker({
      video: this.dom.video,
      hudCanvas: this.dom.hudCanvas,
      isFrontFacing: this.camera ? this.camera.isFrontFacing() : true,
      onPinchStart: (pt) => {
        if (this.state === 'DRAWING') {
          this.drawer.startStroke(pt);
        }
      },
      onPinchMove: (pt) => {
        if (this.state === 'DRAWING') {
          this.drawer.addPoint(pt);
        }
      },
      onPinchEnd: () => {
        if (this.state === 'DRAWING') {
          this.drawer.endStroke();
        }
      },
      onTwoHandMove: (metrics) => {
        if (this.state === 'VIEWING_3D' && this.threeScene) {
          this.threeScene.applyTwoHandTransform(metrics);
          let action = 'Rotate & Pan';
          if (metrics.deltaDist > 0.003) action = 'Zooming IN (+)';
          else if (metrics.deltaDist < -0.003) action = 'Zooming OUT (-)';
          else if (Math.abs(metrics.deltaAngle) > 0.01) action = 'Rotating 3D';
          this._updateStatus(`👐 Two-Hand AR: ${action} • Distance: ${(metrics.dist * 100).toFixed(0)}%`, 'active');
        }
      },
      onTwoHandClap: () => {
        if (this.state === 'VIEWING_3D' && this.threeScene) {
          this.audio.playClick();
          const mode = this.threeScene.cycleMaterialMode();
          this._updateStatus(`✨ Switched Hologram Mode: ${mode}`, 'active');
        }
      },
      onSingleHandMove: ({ deltaX, deltaY }) => {
        if (this.state === 'VIEWING_3D' && this.threeScene) {
          this.threeScene.applySingleHandRotate(deltaX, deltaY);
        }
      },
      onStatusChange: (info) => {
        this._handleTrackerStatus(info);
      }
    });

    try {
      await this.tracker.init();
      this.tracker.start();
      this._updateStatus('Show hand to camera (Pinch thumb & index to draw)', 'ready');
    } catch (e) {
      console.warn('Hand tracker init failed, touch drawing remains active:', e);
      this._updateStatus('AI tracker loading failed. You can draw with finger/mouse!', 'ready');
    }
  }

  _handleTrackerStatus(info) {
    if (this.state !== 'DRAWING') return;

    // Update pinch gauge
    if (this.dom.pinchMeterFill) {
      const pct = Math.round(info.pinchStrength * 100);
      this.dom.pinchMeterFill.style.width = `${pct}%`;
      if (info.isPinching) {
        this.dom.pinchMeterFill.classList.add('pinching');
      } else {
        this.dom.pinchMeterFill.classList.remove('pinching');
      }
    }

    // Status chip text
    if (info.isPinching) {
      this._updateStatus('✨ Pinch Active - Drawing In Air ✨', 'active');
    } else if (info.hasHand) {
      this._updateStatus('👋 Hand Detected - Bring Thumb & Index Together', 'ready');
    } else {
      this._updateStatus('📷 Show Hand to Camera (or sketch with finger/mouse)', 'waiting');
    }
  }

  _onStrokeCountChange(count) {
    this.dom.strokeCounter.textContent = `${count} ${count === 1 ? 'stroke' : 'strokes'}`;
    this.dom.btnUndo.disabled = count === 0;
    this.dom.btnClear.disabled = count === 0;

    if (count > 0) {
      this.dom.btnFinishSketch.classList.add('has-strokes');
    } else {
      this.dom.btnFinishSketch.classList.remove('has-strokes');
    }
  }

  _openPromptModal() {
    this.lastStrokeData = this.drawer.getStrokesData();
    const snapshotUrl = this.drawer.generateSnapshotDataURL(320, 320);
    this.dom.sketchPreviewImg.src = snapshotUrl;

    if (!this.dom.objectPromptInput.value) {
      this.dom.objectPromptInput.value = 'a coffee mug';
    }

    this._setState('PROMPTING');
  }

  _populateQuickTags() {
    this.dom.quickTagsContainer.innerHTML = '';
    const tags = this.speech.getQuickTags();

    tags.forEach((tag) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'quick-tag-chip';
      btn.textContent = tag.label;
      btn.addEventListener('click', () => {
        this.audio.playClick();
        this.dom.objectPromptInput.value = tag.value;
        this.dom.quickTagsContainer.querySelectorAll('.quick-tag-chip').forEach((t) => t.classList.remove('active'));
        btn.classList.add('active');
      });
      this.dom.quickTagsContainer.appendChild(btn);
    });
  }

  async _materializeModel() {
    const promptText = this.dom.objectPromptInput.value.trim();

    // 1. Hide prompt modal and display synthesis progress & time frame modal
    this.dom.promptModal.classList.add('hidden');
    if (this.dom.renderProgressModal) {
      this.dom.renderProgressModal.classList.remove('hidden');
      this.dom.renderProgressTitle.textContent = promptText ? `Synthesizing "${promptText}"` : 'Synthesizing 3D Hologram';
      this.dom.renderProgressPhase.textContent = 'Analyzing air-sketch contours & vectors...';
      this.dom.renderProgressBar.style.width = '15%';
    }

    // 2. High-resolution live timer
    const startTime = performance.now();
    const timerInterval = setInterval(() => {
      const elapsedSec = ((performance.now() - startTime) / 1000).toFixed(2);
      if (this.dom.renderTimerText) {
        this.dom.renderTimerText.textContent = `${elapsedSec}s`;
      }
    }, 30);

    try {
      // Phase 1: Geometry analysis
      await new Promise((r) => setTimeout(r, 260));
      if (this.dom.renderProgressPhase) {
        this.dom.renderProgressPhase.textContent = 'Interpreting semantic archetype & calculating mesh vertices...';
        this.dom.renderProgressBar.style.width = '45%';
      }

      // Phase 2: Mesh Generation
      const result = await this.aiService.generate3D(promptText, this.lastStrokeData);

      await new Promise((r) => setTimeout(r, 260));
      if (this.dom.renderProgressPhase) {
        this.dom.renderProgressPhase.textContent = 'Constructing 3D geometry normals & holographic PBR shaders...';
        this.dom.renderProgressBar.style.width = '80%';
      }

      await new Promise((r) => setTimeout(r, 200));
      if (this.dom.renderProgressPhase) {
        this.dom.renderProgressPhase.textContent = 'Anchoring 3D model into camera AR scene! ✨';
        this.dom.renderProgressBar.style.width = '100%';
      }

      if (result && result.meshGroup) {
        this.currentModelGroup = result.meshGroup;
        this.threeScene.displayModel(result.meshGroup);

        const totalElapsedSec = ((performance.now() - startTime) / 1000).toFixed(2);
        clearInterval(timerInterval);
        if (this.dom.renderTimerText) {
          this.dom.renderTimerText.textContent = `${totalElapsedSec}s`;
        }

        // Update model metadata overlay
        this.dom.modelTitle.textContent = result.meta.title;
        this.dom.modelMeta.textContent = `${result.meta.type} • Rendered in ${totalElapsedSec}s • 360° AR View`;
        this.dom.modelInfoCard.classList.remove('hidden');

        // Short pause to show 100% completion before revealing 3D scene
        await new Promise((r) => setTimeout(r, 300));
        if (this.dom.renderProgressModal) {
          this.dom.renderProgressModal.classList.add('hidden');
        }

        this._setState('VIEWING_3D');
        this.threeScene.resize(window.innerWidth, window.innerHeight);
      } else {
        clearInterval(timerInterval);
        if (this.dom.renderProgressModal) this.dom.renderProgressModal.classList.add('hidden');
        this.dom.promptModal.classList.remove('hidden');
        alert('Could not synthesize 3D model. Please try another prompt.');
      }
    } catch (err) {
      clearInterval(timerInterval);
      if (this.dom.renderProgressModal) this.dom.renderProgressModal.classList.add('hidden');
      this.dom.promptModal.classList.remove('hidden');
      console.error('Materialize error:', err);
      alert(`Generation failed: ${err.message}`);
    }
  }

  _setState(newState) {
    this.state = newState;

    // Reset visibility
    this.dom.welcomeModal.classList.toggle('hidden', newState !== 'ONBOARDING');
    this.dom.promptModal.classList.toggle('hidden', newState !== 'PROMPTING');
    this.dom.drawingToolbar.classList.toggle('hidden', newState !== 'DRAWING');
    this.dom.inspectToolbar.classList.toggle('hidden', newState !== 'VIEWING_3D');
    this.dom.hudCanvas.classList.toggle('hidden', false); // Always visible for live AR hand tracking
    this.dom.drawCanvas.classList.toggle('hidden', newState === 'VIEWING_3D');
    this.dom.threeCanvas.classList.toggle('hidden', newState !== 'VIEWING_3D');

    if (newState === 'DRAWING') {
      this._updateStatus('📷 Show Hand to Camera (Pinch thumb & index to draw)', 'ready');
      this.dom.modelInfoCard.classList.add('hidden');
    } else if (newState === 'VIEWING_3D') {
      this._updateStatus('👐 Two-Hand AR Active: Twist to Rotate • Spread to Zoom • Move to Pan', 'active');
      if (this.threeScene) {
        this.threeScene.resize(window.innerWidth, window.innerHeight);
      }
    }
  }

  _updateStatus(message, type = '') {
    if (this.dom.statusText) {
      this.dom.statusText.textContent = message;
    }
    if (this.dom.statusBadge) {
      this.dom.statusBadge.className = 'status-badge ' + type;
    }
  }
}

// Instantiate on load
window.addEventListener('DOMContentLoaded', () => {
  window.airSketchApp = new App();
});
