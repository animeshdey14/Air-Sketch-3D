/**
 * Designed by Animesh_D
 * AudioFX - Procedural Web Audio API sound generator & haptic feedback
 * Zero external audio files required, runs 100% offline & instantaneous
 */
export class AudioFX {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.drawingOsc = null;
    this.drawingGain = null;
    this.initialized = false;
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.initialized = true;
      }
    } catch (e) {
      console.warn('Web Audio API not supported or blocked:', e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    if (this.muted && this.drawingOsc) {
      this.stopContinuousHum();
    }
    return this.muted;
  }

  vibrate(ms = 30) {
    if (navigator.vibrate) {
      try {
        navigator.vibrate(ms);
      } catch (e) {
        // Ignore vibration errors
      }
    }
  }

  playPinchStart() {
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate(40);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);

    this.startContinuousHum();
  }

  startContinuousHum() {
    if (this.muted || this.drawingOsc || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      this.drawingOsc = this.ctx.createOscillator();
      this.drawingGain = this.ctx.createGain();

      this.drawingOsc.type = 'triangle';
      this.drawingOsc.frequency.setValueAtTime(220, now);

      this.drawingGain.gain.setValueAtTime(0.001, now);
      this.drawingGain.gain.linearRampToValueAtTime(0.04, now + 0.08);

      this.drawingOsc.connect(this.drawingGain);
      this.drawingGain.connect(this.ctx.destination);
      this.drawingOsc.start(now);
    } catch (e) {
      // Ignored
    }
  }

  updateHumPitch(speed = 0) {
    if (this.muted || !this.drawingOsc || !this.ctx) return;
    const baseFreq = 220;
    const targetFreq = Math.min(600, baseFreq + speed * 120);
    this.drawingOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.05);
  }

  stopContinuousHum() {
    if (this.drawingOsc && this.ctx) {
      try {
        const now = this.ctx.currentTime;
        this.drawingGain.gain.linearRampToValueAtTime(0.0001, now + 0.08);
        this.drawingOsc.stop(now + 0.1);
      } catch (e) {
        // Ignored
      }
      this.drawingOsc = null;
      this.drawingGain = null;
    }
  }

  playPinchEnd() {
    this.stopContinuousHum();
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate(20);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(660, now);
    osc.frequency.exponentialRampToValueAtTime(330, now + 0.12);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.15);
  }

  playClear() {
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate([20, 30, 20]);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.22);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  playUndo() {
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate(25);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.linearRampToValueAtTime(480, now + 0.08);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  playClick() {
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate(15);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(200, now + 0.04);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  }

  playMaterialize() {
    if (this.muted) return;
    this.init();
    this.resume();
    if (!this.ctx) return;

    this.vibrate([40, 50, 80]);

    const chords = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    const now = this.ctx.currentTime;

    chords.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0.001, now + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.15, now + idx * 0.08 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.7);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.75);
    });
  }
}
