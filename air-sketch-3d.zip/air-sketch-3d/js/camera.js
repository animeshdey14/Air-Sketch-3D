/**
 * Designed by Animesh_D
 * CameraManager - Handles video stream, front/back switching, permissions & mirroring
 */
export class CameraManager {
  constructor(videoElement, options = {}) {
    this.video = videoElement;
    this.facingMode = options.facingMode || 'user'; // 'user' (front) or 'environment' (back)
    this.stream = null;
    this.isActive = false;
    this.onError = options.onError || console.error;
    this.onReady = options.onReady || null;
    this.onStatusChange = options.onStatusChange || null;
  }

  isFrontFacing() {
    return this.facingMode === 'user';
  }

  async start() {
    if (this.isActive) return;

    this._updateStatus('requesting', 'Requesting camera access...');

    const constraints = {
      audio: false,
      video: {
        facingMode: { ideal: this.facingMode },
        width: { ideal: 1280 },
        height: { ideal: 720 },
        frameRate: { ideal: 30, max: 60 }
      }
    };

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API (getUserMedia) not supported in this browser environment. Please use HTTPS or localhost.');
      }

      // Try with high quality constraints first, fall back to basic video if overconstrained
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: { ideal: this.facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
      } catch (constraintErr) {
        console.warn('Ideal camera constraints failed, falling back to basic { video: true }:', constraintErr);
        this.stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      }

      this.video.setAttribute('playsinline', '');
      this.video.setAttribute('webkit-playsinline', '');
      this.video.muted = true;
      this.video.srcObject = this.stream;

      // Handle video element play safely without hanging
      await new Promise((resolve) => {
        let done = false;
        const finish = () => {
          if (!done) {
            done = true;
            resolve();
          }
        };

        this.video.onloadedmetadata = () => {
          this.video.play().then(finish).catch(finish);
        };

        // Try direct play immediately if metadata is already cached
        this.video.play().then(finish).catch(() => {});

        // Safety fallback timeout
        setTimeout(finish, 1200);
      });

      this.isActive = true;
      this._applyMirroring();
      this._updateStatus('active', 'Camera active');

      if (this.onReady) {
        this.onReady(this.video);
      }
    } catch (err) {
      this.isActive = false;
      let userFriendlyMsg = 'Could not start camera.';

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        userFriendlyMsg = 'Camera permission was denied. Please allow camera access in your browser address bar.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        userFriendlyMsg = 'No camera found on this device. You can still sketch with your finger or mouse!';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        userFriendlyMsg = 'Camera is already in use by another application.';
      } else {
        userFriendlyMsg = `Camera error: ${err.message}`;
      }

      this._updateStatus('error', userFriendlyMsg);
      this.onError(new Error(userFriendlyMsg), err);
      throw new Error(userFriendlyMsg);
    }
  }

  stop() {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (this.video) {
      this.video.srcObject = null;
    }
    this.isActive = false;
    this._updateStatus('stopped', 'Camera stopped');
  }

  async toggleFacingMode() {
    this.facingMode = this.facingMode === 'user' ? 'environment' : 'user';
    if (this.isActive) {
      this.stop();
      await this.start();
    }
    return this.facingMode;
  }

  _applyMirroring() {
    // Only mirror front selfie camera for intuitive air drawing
    if (this.isFrontFacing()) {
      this.video.style.transform = 'scaleX(-1)';
    } else {
      this.video.style.transform = 'scaleX(1)';
    }
  }

  _updateStatus(state, message) {
    if (this.onStatusChange) {
      this.onStatusChange({ state, message, facingMode: this.facingMode });
    }
  }
}
