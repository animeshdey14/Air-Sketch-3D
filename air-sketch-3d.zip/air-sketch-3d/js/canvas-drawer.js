/**
 * Designed by Animesh_D
 * CanvasDrawer - Neon glowing air sketch engine with multi-layer bloom,
 * particle spark trails, stroke smoothing, undo/clear, and touch fallback.
 */
export class CanvasDrawer {
  constructor(canvasElement, options = {}) {
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext('2d');
    this.audio = options.audio || null;

    // Stroke state
    this.strokes = []; // Array of strokes: [ [ {x, y, z, time}, ... ], ... ]
    this.currentStroke = null;
    this.particles = []; // Floating neon spark particles
    this.isDrawing = false;

    // Brush styling
    this.color = '#00f0ff'; // Neon cyan default
    this.lineWidth = 6;
    this.glowColor = '#00f0ff';

    // Callbacks
    this.onStrokeCountChange = options.onStrokeCountChange || null;

    // Animation loop for particles and glowing pulse
    this._startRenderLoop();

    // Enable touch / mouse fallback
    this._initTouchFallback();
  }

  setColor(hexColor) {
    this.color = hexColor;
    this.glowColor = hexColor;
  }

  setLineWidth(width) {
    this.lineWidth = Math.max(2, Math.min(24, width));
  }

  startStroke(point) {
    this.isDrawing = true;
    this.currentStroke = [
      {
        x: point.x,
        y: point.y,
        z: point.z || 0,
        time: performance.now()
      }
    ];

    this._emitParticles(point.x, point.y, 8);
    if (this.audio) this.audio.playPinchStart();
    this._notifyStrokeChange();
  }

  addPoint(point) {
    if (!this.isDrawing || !this.currentStroke) return;

    const prev = this.currentStroke[this.currentStroke.length - 1];
    const dx = point.x - prev.x;
    const dy = point.y - prev.y;
    const dist = Math.hypot(dx, dy);

    // Filter points that are too close together to save memory
    if (dist < 0.003) return;

    this.currentStroke.push({
      x: point.x,
      y: point.y,
      z: point.z || 0,
      time: performance.now()
    });

    // Emit sparks along the movement
    if (dist > 0.01) {
      this._emitParticles(point.x, point.y, Math.min(6, Math.floor(dist * 60) + 1));
      if (this.audio) {
        this.audio.updateHumPitch(dist * 50);
      }
    }
  }

  endStroke() {
    if (!this.isDrawing) return;
    this.isDrawing = false;

    if (this.currentStroke && this.currentStroke.length > 1) {
      this.strokes.push({
        points: this.currentStroke,
        color: this.color,
        lineWidth: this.lineWidth
      });
    }
    this.currentStroke = null;

    if (this.audio) this.audio.playPinchEnd();
    this._notifyStrokeChange();
  }

  undo() {
    if (this.strokes.length > 0) {
      this.strokes.pop();
      if (this.audio) this.audio.playUndo();
      this._notifyStrokeChange();
    }
  }

  clear() {
    if (this.strokes.length > 0 || this.currentStroke) {
      this.strokes = [];
      this.currentStroke = null;
      this.particles = [];
      if (this.audio) this.audio.playClear();
      this._notifyStrokeChange();
    }
  }

  getStrokeCount() {
    return this.strokes.length + (this.currentStroke ? 1 : 0);
  }

  hasStrokes() {
    return this.strokes.length > 0;
  }

  resize() {
    // Canvas dimensions are synced in app.js
  }

  _emitParticles(normX, normY, count = 4) {
    const px = normX * this.canvas.width;
    const py = normY * this.canvas.height;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2.5 + 0.5;
      this.particles.push({
        x: px + (Math.random() - 0.5) * 6,
        y: py + (Math.random() - 0.5) * 6,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 0.5, // Slight upward float
        size: Math.random() * 3 + 1.5,
        alpha: 1.0,
        decay: Math.random() * 0.03 + 0.02,
        color: this.color
      });
    }

    // Cap particles
    if (this.particles.length > 120) {
      this.particles.splice(0, this.particles.length - 120);
    }
  }

  _startRenderLoop() {
    const render = () => {
      this._redraw();
      requestAnimationFrame(render);
    };
    requestAnimationFrame(render);
  }

  _redraw() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    if (w === 0 || h === 0) return;

    ctx.clearRect(0, 0, w, h);

    // 1. Draw completed strokes
    this.strokes.forEach((stroke) => {
      this._drawNeonStroke(stroke.points, stroke.color, stroke.lineWidth, w, h);
    });

    // 2. Draw active in-progress stroke
    if (this.currentStroke && this.currentStroke.length > 1) {
      this._drawNeonStroke(this.currentStroke, this.color, this.lineWidth, w, h);
    }

    // 3. Draw and update particle sparks
    this._updateAndDrawParticles(ctx);
  }

  _drawNeonStroke(points, color, width, w, h) {
    if (points.length < 2) return;
    const ctx = this.ctx;

    // Convert normalized points to canvas space
    const pts = points.map((p) => ({ x: p.x * w, y: p.y * h }));

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Pass 1: Wide soft neon bloom
    ctx.beginPath();
    this._buildSplinePath(ctx, pts);
    ctx.strokeStyle = color;
    ctx.lineWidth = width * 2.2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 24;
    ctx.globalAlpha = 0.5;
    ctx.stroke();

    // Pass 2: Intense mid neon glow
    ctx.beginPath();
    this._buildSplinePath(ctx, pts);
    ctx.lineWidth = width;
    ctx.shadowBlur = 10;
    ctx.globalAlpha = 0.85;
    ctx.stroke();

    // Pass 3: White-hot inner core
    ctx.beginPath();
    this._buildSplinePath(ctx, pts);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = Math.max(1.8, width * 0.35);
    ctx.shadowBlur = 4;
    ctx.shadowColor = '#ffffff';
    ctx.globalAlpha = 0.95;
    ctx.stroke();

    ctx.restore();
  }

  _buildSplinePath(ctx, pts) {
    ctx.moveTo(pts[0].x, pts[0].y);

    if (pts.length === 2) {
      ctx.lineTo(pts[1].x, pts[1].y);
      return;
    }

    // Smooth quadratic bezier curves through midpoints
    for (let i = 1; i < pts.length - 1; i++) {
      const xc = (pts[i].x + pts[i + 1].x) / 2;
      const yc = (pts[i].y + pts[i + 1].y) / 2;
      ctx.quadraticCurveTo(pts[i].x, pts[i].y, xc, yc);
    }
    ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
  }

  _updateAndDrawParticles(ctx) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= p.decay;

      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();

      // White spark center
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * 0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  _initTouchFallback() {
    // Allow users to draw with touch or mouse as an alternative or test mode
    let isTouching = false;

    const getNormCoord = (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      return {
        x: (clientX - rect.left) / rect.width,
        y: (clientY - rect.top) / rect.height,
        z: 0
      };
    };

    const handleStart = (e) => {
      // If clicking interactive UI elements, don't draw
      if (e.target.closest('.ui-interactive, button, input, .modal, .toolbar')) return;
      isTouching = true;
      const pt = getNormCoord(e);
      this.startStroke(pt);
    };

    const handleMove = (e) => {
      if (!isTouching) return;
      const pt = getNormCoord(e);
      this.addPoint(pt);
    };

    const handleEnd = () => {
      if (isTouching) {
        isTouching = false;
        this.endStroke();
      }
    };

    this.canvas.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);

    this.canvas.addEventListener('touchstart', handleStart, { passive: true });
    window.addEventListener('touchmove', handleMove, { passive: true });
    window.addEventListener('touchend', handleEnd, { passive: true });
  }

  _notifyStrokeChange() {
    if (this.onStrokeCountChange) {
      this.onStrokeCountChange(this.getStrokeCount());
    }
  }

  generateSnapshotDataURL(width = 300, height = 300) {
    // Render the sketch to an offscreen square thumbnail with a dark cyber background
    const offCanvas = document.createElement('canvas');
    offCanvas.width = width;
    offCanvas.height = height;
    const offCtx = offCanvas.getContext('2d');

    // Cyber dark gradient background
    const grad = offCtx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width);
    grad.addColorStop(0, '#0d1527');
    grad.addColorStop(1, '#05070d');
    offCtx.fillStyle = grad;
    offCtx.fillRect(0, 0, width, height);

    // Subtle grid lines
    offCtx.strokeStyle = 'rgba(0, 255, 255, 0.08)';
    offCtx.lineWidth = 1;
    const step = 20;
    for (let x = 0; x < width; x += step) {
      offCtx.beginPath();
      offCtx.moveTo(x, 0);
      offCtx.lineTo(x, height);
      offCtx.stroke();
    }
    for (let y = 0; y < height; y += step) {
      offCtx.beginPath();
      offCtx.moveTo(0, y);
      offCtx.lineTo(width, y);
      offCtx.stroke();
    }

    // Draw all strokes
    this.strokes.forEach((stroke) => {
      const pts = stroke.points.map((p) => ({ x: p.x * width, y: p.y * height }));
      if (pts.length < 2) return;

      offCtx.save();
      offCtx.lineCap = 'round';
      offCtx.lineJoin = 'round';

      // Bloom
      offCtx.beginPath();
      this._buildSplinePath(offCtx, pts);
      offCtx.strokeStyle = stroke.color;
      offCtx.lineWidth = stroke.lineWidth * 1.5;
      offCtx.shadowColor = stroke.color;
      offCtx.shadowBlur = 15;
      offCtx.stroke();

      // Core
      offCtx.beginPath();
      this._buildSplinePath(offCtx, pts);
      offCtx.strokeStyle = '#ffffff';
      offCtx.lineWidth = Math.max(1.5, stroke.lineWidth * 0.4);
      offCtx.stroke();

      offCtx.restore();
    });

    // Indelible branding watermark
    offCtx.save();
    offCtx.font = '10px -apple-system, BlinkMacSystemFont, sans-serif';
    offCtx.fillStyle = 'rgba(0, 240, 255, 0.7)';
    offCtx.textAlign = 'right';
    offCtx.fillText('Designed by Animesh_D', width - 10, height - 10);
    offCtx.restore();

    return offCanvas.toDataURL('image/png');
  }

  getStrokesData() {
    // Return all strokes with bounding box info
    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    let totalPoints = 0;

    this.strokes.forEach(s => {
      s.points.forEach(p => {
        if (p.x < minX) minX = p.x;
        if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.y > maxY) maxY = p.y;
        totalPoints++;
      });
    });

    return {
      strokes: this.strokes,
      totalPoints,
      bounds: {
        minX,
        minY,
        maxX,
        maxY,
        width: Math.max(0.01, maxX - minX),
        height: Math.max(0.01, maxY - minY),
        centerX: (minX + maxX) / 2,
        centerY: (minY + maxY) / 2
      },
      primaryColor: this.strokes.length > 0 ? this.strokes[this.strokes.length - 1].color : this.color
    };
  }
}
