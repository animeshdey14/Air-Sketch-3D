/**
 * Designed by Animesh_D
 * HandTracker - MediaPipe Hands integration supporting dual-hand tracking (maxNumHands: 2),
 * pinch gesture detection, coordinate smoothing (EMA), two-hand 3D manipulation
 * (rotate, zoom, pan), mode gestures (two-hand clap/pinch), and futuristic AR HUD overlay.
 */
export class HandTracker {
  constructor(options = {}) {
    this.video = options.video;
    this.hudCanvas = options.hudCanvas;
    this.hudCtx = this.hudCanvas ? this.hudCanvas.getContext('2d') : null;
    this.isFrontFacing = options.isFrontFacing !== undefined ? options.isFrontFacing : true;

    // Single Hand Callbacks
    this.onPinchStart = options.onPinchStart || null;
    this.onPinchMove = options.onPinchMove || null;
    this.onPinchEnd = options.onPinchEnd || null;
    this.onSingleHandMove = options.onSingleHandMove || null;

    // Two-Hand Callbacks (3D Viewport)
    this.onTwoHandMove = options.onTwoHandMove || null;
    this.onTwoHandClap = options.onTwoHandClap || null;

    this.onHandLost = options.onHandLost || null;
    this.onStatusChange = options.onStatusChange || null;

    // State
    this.hands = null;
    this.isLoaded = false;
    this.isProcessing = false;
    this.animFrameId = null;
    this.hasHand = false;
    this.handCount = 0;
    this.isPinching = false;
    this.pinchRatio = 1.0;
    this.pinchStrength = 0; // 0.0 to 1.0

    // Pinch thresholds with hysteresis
    this.PINCH_START_THRESHOLD = 0.28;
    this.PINCH_RELEASE_THRESHOLD = 0.38;

    // Exponential Moving Average smoothing
    this.smoothPos = { x: 0.5, y: 0.5, z: 0 };
    this.SMOOTH_FACTOR = 0.45;

    // Two-Hand Interaction Metrics
    this.prevTwoHand = null;
    this.clapCooldown = 0;
    this.prevSingleHand = null;
  }

  async init() {
    if (this.isLoaded) return;
    this._notifyStatus('loading', 'Loading AI hand tracker...');

    // Wait for global Hands object from CDN
    let attempts = 0;
    while (!window.Hands && attempts < 50) {
      await new Promise((r) => setTimeout(r, 100));
      attempts++;
    }

    if (!window.Hands) {
      const err = new Error('MediaPipe Hands library not loaded from CDN.');
      this._notifyStatus('error', err.message);
      throw err;
    }

    this.hands = new window.Hands({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${file}`
    });

    // Track up to 2 hands for two-handed 3D object rotation, zooming, and mode switching!
    this.hands.setOptions({
      maxNumHands: 2,
      modelComplexity: 1,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.5
    });

    this.hands.onResults((results) => this._handleResults(results));
    this.isLoaded = true;
    this._notifyStatus('ready', 'Hand tracker ready. Show hand to camera!');
  }

  start() {
    if (!this.isLoaded || this.isProcessing) return;
    this.isProcessing = true;
    this._isBusy = false;
    this._loop();
  }

  stop() {
    this.isProcessing = false;
    this._isBusy = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.isPinching) {
      this.isPinching = false;
      if (this.onPinchEnd) this.onPinchEnd();
    }
    this.hasHand = false;
    this.handCount = 0;
    this.prevTwoHand = null;
    this.prevSingleHand = null;
    this._clearHUD();
  }

  setFrontFacing(isFront) {
    this.isFrontFacing = isFront;
  }

  async _loop() {
    if (!this.isProcessing) return;

    if (this.video && this.video.readyState >= 2 && !this.video.paused && !this._isBusy) {
      this._isBusy = true;
      try {
        await this.hands.send({ image: this.video });
      } catch (err) {
        console.warn('MediaPipe send frame error:', err);
      } finally {
        this._isBusy = false;
      }
    }

    this.animFrameId = requestAnimationFrame(() => this._loop());
  }

  _extractHand(landmarks, handIndex) {
    const wrist = landmarks[0];
    const thumb = landmarks[4];
    const index = landmarks[8];
    const middleMcp = landmarks[9];

    const handScale = Math.hypot(wrist.x - middleMcp.x, wrist.y - middleMcp.y) || 0.2;
    const rawDist = Math.hypot(thumb.x - index.x, thumb.y - index.y);
    const pinchRatio = rawDist / handScale;
    const pinchStrength = Math.max(0, Math.min(1, (0.45 - pinchRatio) / (0.45 - 0.20)));

    let midX = (thumb.x + index.x) / 2;
    const midY = (thumb.y + index.y) / 2;
    const midZ = (thumb.z + index.z) / 2;

    if (this.isFrontFacing) {
      midX = 1.0 - midX;
    }

    return {
      index: handIndex,
      landmarks,
      x: midX,
      y: midY,
      z: midZ,
      wrist,
      thumb,
      indexTip: index,
      handScale,
      pinchRatio,
      pinchStrength,
      isPinching: pinchRatio < this.PINCH_START_THRESHOLD
    };
  }

  _handleResults(results) {
    this._clearHUD();

    if (this.clapCooldown > 0) {
      this.clapCooldown--;
    }

    const multi = results.multiHandLandmarks;
    if (!multi || multi.length === 0) {
      if (this.hasHand) {
        this.hasHand = false;
        this.handCount = 0;
        this.prevTwoHand = null;
        this.prevSingleHand = null;
        if (this.isPinching) {
          this.isPinching = false;
          if (this.onPinchEnd) this.onPinchEnd();
        }
        if (this.onHandLost) this.onHandLost();
        this._notifyStatus('searching', 'Searching for hand...');
      }
      return;
    }

    this.hasHand = true;
    this.handCount = multi.length;

    // =========================================================================
    // CASE A: Two Hands Detected (Full 3D Rotate, Zoom, Pan & Mode Gestures)
    // =========================================================================
    if (multi.length >= 2) {
      const h0 = this._extractHand(multi[0], 0);
      const h1 = this._extractHand(multi[1], 1);

      // Distance between both hands in screen space
      const dist = Math.hypot(h0.x - h1.x, h0.y - h1.y);
      // Angle between hands (-PI to PI)
      const angle = Math.atan2(h1.y - h0.y, h1.x - h0.x);
      // Midpoint between hands
      const midX = (h0.x + h1.x) / 2;
      const midY = (h0.y + h1.y) / 2;

      let deltaDist = 0;
      let deltaAngle = 0;
      let deltaMidX = 0;
      let deltaMidY = 0;

      if (this.prevTwoHand) {
        deltaDist = dist - this.prevTwoHand.dist;
        deltaAngle = angle - this.prevTwoHand.angle;

        // Normalize angle delta for circular wrap-around
        if (deltaAngle > Math.PI) deltaAngle -= Math.PI * 2;
        if (deltaAngle < -Math.PI) deltaAngle += Math.PI * 2;

        deltaMidX = midX - this.prevTwoHand.midX;
        deltaMidY = midY - this.prevTwoHand.midY;

        // Detect Two-Hand Clap / Double Tap Gesture (bring hands close together)
        if (dist < 0.12 && this.prevTwoHand.dist > 0.18 && this.clapCooldown === 0) {
          this.clapCooldown = 25; // debounce ~0.8s
          if (this.onTwoHandClap) {
            this.onTwoHandClap();
          }
        }
      }

      this.prevTwoHand = { dist, angle, midX, midY };
      this.prevSingleHand = null;

      // Two-Hand Gesture Callback for 3D Viewport
      if (this.onTwoHandMove) {
        this.onTwoHandMove({
          h0,
          h1,
          dist,
          angle,
          midX,
          midY,
          deltaDist,
          deltaAngle,
          deltaMidX,
          deltaMidY,
          bothPinching: h0.isPinching && h1.isPinching
        });
      }

      // Render futuristic Two-Hand Holographic HUD
      this._renderTwoHandHUD(h0, h1, dist, angle, midX, midY);
      return;
    }

    // =========================================================================
    // CASE B: Single Hand Detected (Air Sketching or Single-Hand 3D Rotate)
    // =========================================================================
    this.prevTwoHand = null;
    const h0 = this._extractHand(multi[0], 0);

    // Exponential Moving Average smoothing
    this.smoothPos.x += (h0.x - this.smoothPos.x) * this.SMOOTH_FACTOR;
    this.smoothPos.y += (h0.y - this.smoothPos.y) * this.SMOOTH_FACTOR;
    this.smoothPos.z += (h0.z - this.smoothPos.z) * this.SMOOTH_FACTOR;

    const currentPoint = {
      x: this.smoothPos.x,
      y: this.smoothPos.y,
      z: this.smoothPos.z,
      rawX: h0.x,
      rawY: h0.y,
      strength: h0.pinchStrength
    };

    // Calculate single hand delta for 3D rotation fallback
    if (this.prevSingleHand) {
      const deltaX = currentPoint.x - this.prevSingleHand.x;
      const deltaY = currentPoint.y - this.prevSingleHand.y;
      if (this.onSingleHandMove) {
        this.onSingleHandMove({ hand: currentPoint, deltaX, deltaY });
      }
    }
    this.prevSingleHand = { x: currentPoint.x, y: currentPoint.y };

    // Pinch state machine for air sketching
    this.pinchRatio = h0.pinchRatio;
    this.pinchStrength = h0.pinchStrength;

    if (!this.isPinching) {
      if (this.pinchRatio < this.PINCH_START_THRESHOLD) {
        this.isPinching = true;
        this._notifyStatus('pinching', 'Pinch Active - Drawing In Air ✨');
        if (this.onPinchStart) this.onPinchStart(currentPoint);
      } else {
        this._notifyStatus('detected', '1 Hand Detected (Bring 2nd hand to Zoom & Rotate 3D!)');
      }
    } else {
      if (this.pinchRatio > this.PINCH_RELEASE_THRESHOLD) {
        this.isPinching = false;
        this._notifyStatus('detected', 'Pinch Released - Drawing Stopped');
        if (this.onPinchEnd) this.onPinchEnd();
      } else {
        if (this.onPinchMove) this.onPinchMove(currentPoint);
      }
    }

    // Render single hand HUD
    this._renderSingleHandHUD(h0.landmarks, currentPoint, '#00f0ff');
  }

  _renderSingleHandHUD(landmarks, point, color = '#00f0ff') {
    if (!this.hudCtx || !this.hudCanvas) return;
    const ctx = this.hudCtx;
    const w = this.hudCanvas.width;
    const h = this.hudCanvas.height;

    const toPx = (lm) => ({
      x: this.isFrontFacing ? (1.0 - lm.x) * w : lm.x * w,
      y: lm.y * h
    });

    const connections = [
      [0, 1], [1, 2], [2, 3], [3, 4],
      [0, 5], [5, 6], [6, 7], [7, 8],
      [0, 9], [9, 10], [10, 11], [11, 12],
      [0, 13], [13, 14], [14, 15], [15, 16],
      [0, 17], [17, 18], [18, 19], [19, 20],
      [5, 9], [9, 13], [13, 17]
    ];

    ctx.save();

    // Laser skeleton
    ctx.strokeStyle = this.isPinching ? 'rgba(0, 245, 255, 0.45)' : 'rgba(100, 200, 255, 0.25)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    connections.forEach(([i, j]) => {
      const p1 = toPx(landmarks[i]);
      const p2 = toPx(landmarks[j]);
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
    });
    ctx.stroke();

    // Joint dots
    landmarks.forEach((lm, idx) => {
      if (idx === 4 || idx === 8) return;
      const pt = toPx(lm);
      ctx.fillStyle = 'rgba(0, 230, 255, 0.5)';
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Reticle at fingertip
    const midPx = { x: point.x * w, y: point.y * h };
    const outerRadius = this.isPinching ? 16 : 14 + (1 - this.pinchStrength) * 10;

    ctx.beginPath();
    ctx.arc(midPx.x, midPx.y, outerRadius, 0, Math.PI * 2);
    ctx.strokeStyle = this.isPinching ? '#00ffff' : color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(midPx.x, midPx.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();

    ctx.restore();
  }

  _renderTwoHandHUD(h0, h1, dist, angle, midX, midY) {
    if (!this.hudCtx || !this.hudCanvas) return;
    const ctx = this.hudCtx;
    const w = this.hudCanvas.width;
    const h = this.hudCanvas.height;

    // Render skeleton for Hand 0 (Neon Cyan) and Hand 1 (Laser Magenta)
    this._renderSingleHandHUD(h0.landmarks, h0, '#00f0ff');
    this._renderSingleHandHUD(h1.landmarks, h1, '#ff007f');

    const p0 = { x: h0.x * w, y: h0.y * h };
    const p1 = { x: h1.x * w, y: h1.y * h };
    const center = { x: midX * w, y: midY * h };

    ctx.save();

    // 1. Glowing AR Energy Link Beam between both hands
    const grad = ctx.createLinearGradient(p0.x, p0.y, p1.x, p1.y);
    grad.addColorStop(0, 'rgba(0, 240, 255, 0.8)');
    grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.9)');
    grad.addColorStop(1, 'rgba(255, 0, 127, 0.8)');

    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.lineTo(p1.x, p1.y);
    ctx.strokeStyle = grad;
    ctx.lineWidth = 3;
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 16;
    ctx.stroke();

    // 2. Center Targeting Reticle
    ctx.beginPath();
    ctx.arc(center.x, center.y, 14, 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // 3. Futuristic Metric Chip on the Beam
    const deg = Math.round((angle * 180) / Math.PI);
    const distPct = Math.round(dist * 100);
    const badgeText = `👐 2-HAND AR • ZOOM: ${distPct}% • ROT: ${deg}°`;

    ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    const textMetrics = ctx.measureText(badgeText);
    const boxW = textMetrics.width + 16;
    const boxH = 22;

    ctx.fillStyle = 'rgba(7, 12, 24, 0.85)';
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(center.x - boxW / 2, center.y - 32, boxW, boxH, 6);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#00f0ff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(badgeText, center.x, center.y - 21);

    ctx.restore();
  }

  _clearHUD() {
    if (this.hudCtx && this.hudCanvas) {
      this.hudCtx.clearRect(0, 0, this.hudCanvas.width, this.hudCanvas.height);
    }
  }

  _notifyStatus(state, message) {
    if (this.onStatusChange) {
      this.onStatusChange({
        state,
        message,
        hasHand: this.hasHand,
        handCount: this.handCount,
        isPinching: this.isPinching,
        pinchStrength: this.pinchStrength
      });
    }
  }
}
