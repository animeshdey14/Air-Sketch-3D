/**
 * Designed by Animesh_D
 * Procedural3D - Rich semantic 3D model generator with high-tech materials,
 * animations, and archetype recognition tailored to air sketches.
 */
export class Procedural3D {
  /**
   * Generates a 3D model based on user text description and sketch characteristics
   */
  static createModel(promptText = '', strokeData = null) {
    const THREE = window.THREE;
    if (!THREE) return null;

    const query = (promptText || '').toLowerCase().trim();
    const primaryColor = strokeData && strokeData.primaryColor ? strokeData.primaryColor : '#00f0ff';
    const hexColor = parseInt(primaryColor.replace('#', '0x'), 16) || 0x00f0ff;

    // Semantic matching
    if (this._matches(query, ['car', 'sports car', 'vehicle', 'automobile', 'racecar', 'truck'])) {
      return this._createSportsCar(THREE, hexColor);
    }
    if (this._matches(query, ['mug', 'coffee', 'cup', 'tea', 'espresso'])) {
      return this._createCoffeeMug(THREE, hexColor);
    }
    if (this._matches(query, ['sword', 'blade', 'katana', 'saber', 'weapon', 'dagger'])) {
      return this._createLaserSword(THREE, hexColor);
    }
    if (this._matches(query, ['spaceship', 'rocket', 'ufo', 'shuttle', 'ship', 'craft'])) {
      return this._createSpaceship(THREE, hexColor);
    }
    if (this._matches(query, ['ring', 'diamond', 'jewel', 'jewelry', 'band'])) {
      return this._createDiamondRing(THREE, hexColor);
    }
    if (this._matches(query, ['tree', 'plant', 'flower', 'forest', 'nature'])) {
      return this._createCyberTree(THREE, hexColor);
    }
    if (this._matches(query, ['cat', 'kitten', 'dog', 'puppy', 'animal', 'pet', 'bear'])) {
      return this._createCuteCat(THREE, hexColor);
    }
    if (this._matches(query, ['vase', 'bottle', 'glass', 'wine', 'pottery', 'goblet'])) {
      return this._createCrystalVase(THREE, hexColor);
    }
    if (this._matches(query, ['heart', 'love', 'valentines'])) {
      return this._createHeart(THREE, hexColor);
    }
    if (this._matches(query, ['star', 'sparkle', 'cosmos', 'sun', 'nova'])) {
      return this._createStar(THREE, hexColor);
    }
    if (this._matches(query, ['plane', 'airplane', 'jet', 'aircraft', 'flyer'])) {
      return this._createJetAirplane(THREE, hexColor);
    }
    if (this._matches(query, ['planet', 'orb', 'globe', 'saturn', 'sphere', 'world'])) {
      return this._createRingedPlanet(THREE, hexColor);
    }

    // Default: If prompt is unrecognized or empty, create a futuristic Holographic Artifact
    return this._createHoloArtifact(THREE, hexColor, query || 'Air Creation');
  }

  static _matches(query, keywords) {
    return keywords.some((kw) => query.includes(kw));
  }

  // 1. Cyberpunk Sports Car
  static _createSportsCar(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'SportsCar';

    const carPaint = new THREE.MeshStandardMaterial({
      color: accentColor,
      metalness: 0.85,
      roughness: 0.2,
      envMapIntensity: 1.0
    });
    const darkMetal = new THREE.MeshStandardMaterial({ color: 0x111318, roughness: 0.4, metalness: 0.8 });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x112233,
      metalness: 0.9,
      roughness: 0.1,
      transmission: 0.7,
      transparent: true,
      opacity: 0.85
    });
    const glowMat = new THREE.MeshStandardMaterial({
      color: 0x00ffff,
      emissive: 0x00ffff,
      emissiveIntensity: 1.5
    });
    const redGlow = new THREE.MeshStandardMaterial({
      color: 0xff0044,
      emissive: 0xff0044,
      emissiveIntensity: 1.5
    });

    // Main Chassis lower body
    const bodyGeo = new THREE.BoxGeometry(2.2, 0.45, 4.2);
    const body = new THREE.Mesh(bodyGeo, carPaint);
    body.position.y = 0.4;
    group.add(body);

    // Front hood slope
    const hoodGeo = new THREE.CylinderGeometry(1.05, 1.1, 1.2, 4);
    hoodGeo.rotateY(Math.PI / 4);
    const hood = new THREE.Mesh(hoodGeo, carPaint);
    hood.position.set(0, 0.5, 1.2);
    hood.scale.set(1, 0.35, 1.4);
    group.add(hood);

    // Cabin / Windshield
    const cabinGeo = new THREE.BoxGeometry(1.6, 0.65, 2.0);
    const cabin = new THREE.Mesh(cabinGeo, glassMat);
    cabin.position.set(0, 0.85, -0.2);
    group.add(cabin);

    // Rear Spoiler
    const spoilerGeo = new THREE.BoxGeometry(2.0, 0.08, 0.4);
    const spoiler = new THREE.Mesh(spoilerGeo, darkMetal);
    spoiler.position.set(0, 1.0, -1.9);
    group.add(spoiler);

    const strut1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), darkMetal);
    strut1.position.set(-0.7, 0.8, -1.9);
    const strut2 = strut1.clone();
    strut2.position.x = 0.7;
    group.add(strut1, strut2);

    // Headlights & Taillights
    const hlGeo = new THREE.BoxGeometry(0.45, 0.1, 0.08);
    const hlLeft = new THREE.Mesh(hlGeo, glowMat);
    hlLeft.position.set(-0.75, 0.45, 2.12);
    const hlRight = hlLeft.clone();
    hlRight.position.x = 0.75;
    group.add(hlLeft, hlRight);

    const tlLeft = new THREE.Mesh(hlGeo, redGlow);
    tlLeft.position.set(-0.75, 0.48, -2.12);
    const tlRight = tlLeft.clone();
    tlRight.position.x = 0.75;
    group.add(tlLeft, tlRight);

    // 4 Wheels
    const wheelGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.35, 24);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.7 });
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.2 });

    const wheelPositions = [
      [-1.15, 0.42, 1.3],
      [1.15, 0.42, 1.3],
      [-1.15, 0.42, -1.3],
      [1.15, 0.42, -1.3]
    ];

    wheelPositions.forEach(([x, y, z]) => {
      const wGroup = new THREE.Group();
      const tire = new THREE.Mesh(wheelGeo, wheelMat);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.36, 12), rimMat);
      rim.rotateZ(Math.PI / 2);
      wGroup.add(tire, rim);
      wGroup.position.set(x, y, z);
      group.add(wGroup);
    });

    group.scale.set(0.65, 0.65, 0.65);
    return group;
  }

  // 2. High-Tech Coffee Mug
  static _createCoffeeMug(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'CoffeeMug';

    const ceramicMat = new THREE.MeshPhysicalMaterial({
      color: accentColor,
      roughness: 0.15,
      metalness: 0.1,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1
    });
    const innerMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
    const coffeeMat = new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.1 });

    // Outer Mug Body
    const outerGeo = new THREE.CylinderGeometry(1.0, 0.85, 2.2, 32, 1, true);
    const outer = new THREE.Mesh(outerGeo, ceramicMat);
    group.add(outer);

    // Inner Hollow
    const innerGeo = new THREE.CylinderGeometry(0.92, 0.78, 2.15, 32, 1, true);
    const inner = new THREE.Mesh(innerGeo, innerMat);
    group.add(inner);

    // Bottom
    const bottomGeo = new THREE.CircleGeometry(0.85, 32);
    bottomGeo.rotateX(Math.PI / 2);
    const bottom = new THREE.Mesh(bottomGeo, ceramicMat);
    bottom.position.y = -1.1;
    group.add(bottom);

    // Rim ring
    const rimGeo = new THREE.TorusGeometry(0.96, 0.045, 16, 32);
    rimGeo.rotateX(Math.PI / 2);
    const rim = new THREE.Mesh(rimGeo, ceramicMat);
    rim.position.y = 1.1;
    group.add(rim);

    // Coffee Liquid
    const liquidGeo = new THREE.CircleGeometry(0.9, 32);
    liquidGeo.rotateX(-Math.PI / 2);
    const liquid = new THREE.Mesh(liquidGeo, coffeeMat);
    liquid.position.y = 0.8;
    group.add(liquid);

    // Handle
    const handleGeo = new THREE.TorusGeometry(0.7, 0.12, 16, 32, Math.PI);
    handleGeo.rotateZ(-Math.PI / 2);
    const handle = new THREE.Mesh(handleGeo, ceramicMat);
    handle.position.set(1.1, 0, 0);
    group.add(handle);

    group.scale.set(0.9, 0.9, 0.9);
    return group;
  }

  // 3. Cyber Energy Katana / Laser Sword
  static _createLaserSword(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'LaserSword';

    const hiltMat = new THREE.MeshStandardMaterial({ color: 0x22252a, metalness: 0.9, roughness: 0.3 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.85, roughness: 0.2 });
    const bladeMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      emissive: accentColor,
      emissiveIntensity: 2.0,
      roughness: 0.1
    });

    // Hilt / Handle
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 1.4, 16), hiltMat);
    hilt.position.y = -1.0;
    group.add(hilt);

    // Pommel
    const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), goldMat);
    pommel.position.y = -1.75;
    group.add(pommel);

    // Crossguard
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.12, 0.3), goldMat);
    guard.position.y = -0.28;
    group.add(guard);

    // Glowing Laser Blade
    const blade = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 3.2, 16), bladeMat);
    blade.position.y = 1.35;
    group.add(blade);

    // Blade Tip
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.4, 16), bladeMat);
    tip.position.y = 3.15;
    group.add(tip);

    // Inner White Core
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const core = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 3.4, 12), coreMat);
    core.position.y = 1.45;
    group.add(core);

    group.scale.set(0.7, 0.7, 0.7);
    group.rotation.z = -Math.PI / 6;
    return group;
  }

  // 4. Sci-Fi Spaceship
  static _createSpaceship(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'Spaceship';

    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x222b38,
      roughness: 0.3,
      metalness: 0.8
    });
    const accentMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      emissive: accentColor,
      emissiveIntensity: 0.4,
      metalness: 0.9,
      roughness: 0.2
    });
    const cockpitMat = new THREE.MeshPhysicalMaterial({
      color: 0x00e5ff,
      roughness: 0.1,
      transmission: 0.8,
      transparent: true,
      opacity: 0.85
    });
    const thrusterGlow = new THREE.MeshBasicMaterial({ color: 0x00ffff });

    // Fuselage
    const fuseGeo = new THREE.ConeGeometry(0.9, 3.8, 4);
    fuseGeo.rotateY(Math.PI / 4);
    fuseGeo.rotateX(-Math.PI / 2);
    const fuse = new THREE.Mesh(fuseGeo, hullMat);
    group.add(fuse);

    // Cockpit Canopy
    const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 16), cockpitMat);
    canopy.scale.set(0.8, 0.5, 1.4);
    canopy.position.set(0, 0.4, 0.2);
    group.add(canopy);

    // Swept Delta Wings
    const wingShape = new THREE.Shape();
    wingShape.moveTo(0, 0);
    wingShape.lineTo(2.4, -1.2);
    wingShape.lineTo(2.2, -1.8);
    wingShape.lineTo(0, -1.2);
    wingShape.closePath();

    const wingGeo = new THREE.ExtrudeGeometry(wingShape, { depth: 0.08, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03 });
    wingGeo.center();
    wingGeo.rotateX(Math.PI / 2);

    const wings = new THREE.Mesh(wingGeo, accentMat);
    wings.position.set(0, -0.05, -0.4);
    group.add(wings);

    // Twin Thrusters
    const t1 = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.3, 0.7, 16), hullMat);
    t1.rotateX(Math.PI / 2);
    t1.position.set(-0.55, -0.05, -1.9);

    const t2 = t1.clone();
    t2.position.x = 0.55;

    // Thruster exhaust flames
    const flameGeo = new THREE.ConeGeometry(0.18, 0.8, 16);
    flameGeo.rotateX(-Math.PI / 2);
    const f1 = new THREE.Mesh(flameGeo, thrusterGlow);
    f1.position.set(-0.55, -0.05, -2.4);
    const f2 = f1.clone();
    f2.position.x = 0.55;

    group.add(t1, t2, f1, f2);

    group.scale.set(0.7, 0.7, 0.7);
    return group;
  }

  // 5. Brilliant Diamond Ring
  static _createDiamondRing(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'DiamondRing';

    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf5f5f7, // Platinum / white gold
      metalness: 0.95,
      roughness: 0.15
    });
    const gemMat = new THREE.MeshPhysicalMaterial({
      color: accentColor,
      transmission: 0.9,
      roughness: 0.05,
      ior: 2.417, // Diamond refraction index
      transparent: true,
      opacity: 0.95,
      emissive: accentColor,
      emissiveIntensity: 0.3
    });

    // Band
    const bandGeo = new THREE.TorusGeometry(1.2, 0.14, 24, 48);
    const band = new THREE.Mesh(bandGeo, goldMat);
    group.add(band);

    // Mount Prongs
    const mountGeo = new THREE.CylinderGeometry(0.35, 0.15, 0.45, 6);
    const mount = new THREE.Mesh(mountGeo, goldMat);
    mount.position.y = 1.3;
    group.add(mount);

    // Diamond Gemstone
    const gemGeo = new THREE.OctahedronGeometry(0.55, 1);
    const gem = new THREE.Mesh(gemGeo, gemMat);
    gem.position.y = 1.6;
    gem.scale.set(1, 1.2, 1);
    group.add(gem);

    group.scale.set(0.9, 0.9, 0.9);
    return group;
  }

  // 6. Cyber / Magical Tree
  static _createCyberTree(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'CyberTree';

    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3525, roughness: 0.8 });
    const leafMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      roughness: 0.3,
      emissive: accentColor,
      emissiveIntensity: 0.35
    });

    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.22, 0.45, 2.2, 12);
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = 0;
    group.add(trunk);

    // Foliage Clusters
    const foliageOffsets = [
      [0, 1.4, 0, 0.95],
      [-0.45, 0.9, 0.3, 0.65],
      [0.45, 0.8, -0.3, 0.65],
      [0.2, 1.2, 0.4, 0.55],
      [-0.3, 1.3, -0.35, 0.55]
    ];

    foliageOffsets.forEach(([x, y, z, s]) => {
      const foliage = new THREE.Mesh(new THREE.DodecahedronGeometry(s, 1), leafMat);
      foliage.position.set(x, y, z);
      group.add(foliage);
    });

    group.scale.set(0.9, 0.9, 0.9);
    return group;
  }

  // 7. Stylized Cute Cat
  static _createCuteCat(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'CuteCat';

    const furMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      roughness: 0.5,
      metalness: 0.1
    });
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.3 });

    // Body
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.85, 24, 24), furMat);
    body.scale.set(1.0, 1.2, 1.0);
    body.position.y = 0;
    group.add(body);

    // Head
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.72, 24, 24), furMat);
    head.position.set(0, 1.3, 0.15);
    group.add(head);

    // Ears
    const earGeo = new THREE.ConeGeometry(0.28, 0.5, 4);
    const earLeft = new THREE.Mesh(earGeo, furMat);
    earLeft.position.set(-0.42, 1.9, 0.15);
    earLeft.rotation.z = 0.25;

    const earRight = new THREE.Mesh(earGeo, furMat);
    earRight.position.set(0.42, 1.9, 0.15);
    earRight.rotation.z = -0.25;
    group.add(earLeft, earRight);

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.1, 16, 16);
    const eyeLeft = new THREE.Mesh(eyeGeo, darkMat);
    eyeLeft.position.set(-0.25, 1.4, 0.78);
    const eyeRight = eyeLeft.clone();
    eyeRight.position.x = 0.25;
    group.add(eyeLeft, eyeRight);

    // Snout / Nose
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.08, 3), darkMat);
    nose.rotateX(-Math.PI / 2);
    nose.position.set(0, 1.25, 0.85);
    group.add(nose);

    // Belly patch
    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.55, 16, 16), whiteMat);
    belly.scale.set(0.8, 1.1, 0.4);
    belly.position.set(0, 0, 0.72);
    group.add(belly);

    // Tail
    const tailCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.6, -0.7),
      new THREE.Vector3(0, -0.2, -1.1),
      new THREE.Vector3(0.25, 0.4, -1.2)
    ]);
    const tail = new THREE.Mesh(new THREE.TubeGeometry(tailCurve, 16, 0.1, 8, false), furMat);
    group.add(tail);

    group.scale.set(0.85, 0.85, 0.85);
    return group;
  }

  // 8. Crystal Vase
  static _createCrystalVase(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'CrystalVase';

    const points = [
      new THREE.Vector2(0.45, -1.4),
      new THREE.Vector2(0.8, -1.0),
      new THREE.Vector2(0.95, -0.2),
      new THREE.Vector2(0.4, 0.6),
      new THREE.Vector2(0.35, 1.0),
      new THREE.Vector2(0.65, 1.4)
    ];

    const latheGeo = new THREE.LatheGeometry(points, 32);
    const crystalMat = new THREE.MeshPhysicalMaterial({
      color: accentColor,
      roughness: 0.1,
      metalness: 0.1,
      transmission: 0.85,
      ior: 1.52,
      transparent: true,
      opacity: 0.9,
      emissive: accentColor,
      emissiveIntensity: 0.2
    });

    const vase = new THREE.Mesh(latheGeo, crystalMat);
    group.add(vase);

    group.scale.set(0.85, 0.85, 0.85);
    return group;
  }

  // 9. 3D Puffed Heart
  static _createHeart(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'Heart';

    const x = 0, y = 0;
    const heartShape = new THREE.Shape();
    heartShape.moveTo(x + 0.25, y + 0.25);
    heartShape.bezierCurveTo(x + 0.25, y + 0.25, x + 0.2, y, x, y);
    heartShape.bezierCurveTo(x - 0.3, y, x - 0.3, y + 0.35, x - 0.3, y + 0.35);
    heartShape.bezierCurveTo(x - 0.3, y + 0.55, x - 0.1, y + 0.77, x + 0.25, y + 1.0);
    heartShape.bezierCurveTo(x + 0.6, y + 0.77, x + 0.8, y + 0.55, x + 0.8, y + 0.35);
    heartShape.bezierCurveTo(x + 0.8, y + 0.35, x + 0.8, y, x + 0.5, y);
    heartShape.bezierCurveTo(x + 0.35, y, x + 0.25, y + 0.25, x + 0.25, y + 0.25);

    const extrudeSettings = {
      depth: 0.4,
      bevelEnabled: true,
      bevelSegments: 6,
      steps: 2,
      bevelSize: 0.25,
      bevelThickness: 0.25
    };

    const geometry = new THREE.ExtrudeGeometry(heartShape, extrudeSettings);
    geometry.center();
    geometry.rotateZ(Math.PI); // Orient upright

    const heartMat = new THREE.MeshPhysicalMaterial({
      color: 0xff0055,
      roughness: 0.2,
      metalness: 0.3,
      clearcoat: 1.0,
      emissive: 0xff0044,
      emissiveIntensity: 0.4
    });

    const mesh = new THREE.Mesh(geometry, heartMat);
    group.add(mesh);

    group.scale.set(1.5, 1.5, 1.5);
    return group;
  }

  // 10. Cosmic 3D Star
  static _createStar(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'CosmicStar';

    const starShape = new THREE.Shape();
    const points = 5;
    const outerR = 1.4;
    const innerR = 0.6;

    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 === 0 ? outerR : innerR;
      const angle = (i * Math.PI) / points - Math.PI / 2;
      const sx = Math.cos(angle) * r;
      const sy = Math.sin(angle) * r;
      if (i === 0) starShape.moveTo(sx, sy);
      else starShape.lineTo(sx, sy);
    }
    starShape.closePath();

    const starGeo = new THREE.ExtrudeGeometry(starShape, {
      depth: 0.3,
      bevelEnabled: true,
      bevelThickness: 0.2,
      bevelSize: 0.1,
      bevelSegments: 4
    });
    starGeo.center();

    const starMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      roughness: 0.2,
      metalness: 0.8,
      emissive: 0xffa500,
      emissiveIntensity: 0.5
    });

    const star = new THREE.Mesh(starGeo, starMat);
    group.add(star);

    group.scale.set(0.9, 0.9, 0.9);
    return group;
  }

  // 11. Jet Airplane
  static _createJetAirplane(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'JetAirplane';

    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xe6e8eb, roughness: 0.3, metalness: 0.5 });
    const blueMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.2, metalness: 0.7 });

    // Fuselage
    const fuseGeo = new THREE.CylinderGeometry(0.35, 0.25, 4.0, 16);
    fuseGeo.rotateX(Math.PI / 2);
    const fuselage = new THREE.Mesh(fuseGeo, whiteMat);
    group.add(fuselage);

    // Cockpit nose cone
    const noseGeo = new THREE.ConeGeometry(0.35, 1.0, 16);
    noseGeo.rotateX(-Math.PI / 2);
    const nose = new THREE.Mesh(noseGeo, blueMat);
    nose.position.z = 2.5;
    group.add(nose);

    // Main Wings
    const wingGeo = new THREE.BoxGeometry(4.6, 0.08, 1.1);
    const wings = new THREE.Mesh(wingGeo, blueMat);
    wings.position.set(0, 0, 0.2);
    group.add(wings);

    // Tail Fin
    const finGeo = new THREE.BoxGeometry(0.08, 1.0, 0.8);
    const fin = new THREE.Mesh(finGeo, blueMat);
    fin.position.set(0, 0.6, -1.7);
    group.add(fin);

    group.scale.set(0.7, 0.7, 0.7);
    return group;
  }

  // 12. Ringed Planet
  static _createRingedPlanet(THREE, accentColor) {
    const group = new THREE.Group();
    group.name = 'RingedPlanet';

    const planetMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      roughness: 0.4,
      metalness: 0.3
    });
    const ringMat = new THREE.MeshPhysicalMaterial({
      color: 0xddc59a,
      roughness: 0.3,
      metalness: 0.2,
      transmission: 0.4,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide
    });

    const orb = new THREE.Mesh(new THREE.SphereGeometry(1.1, 32, 32), planetMat);
    group.add(orb);

    const ringGeo = new THREE.RingGeometry(1.5, 2.4, 48);
    ringGeo.rotateX(Math.PI / 2.3);
    const ring = new THREE.Mesh(ringGeo, ringMat);
    group.add(ring);

    group.scale.set(0.85, 0.85, 0.85);
    return group;
  }

  // Fallback: Holographic Core Artifact
  static _createHoloArtifact(THREE, accentColor, label = '') {
    const group = new THREE.Group();
    group.name = 'HoloArtifact';

    const coreMat = new THREE.MeshPhysicalMaterial({
      color: accentColor,
      roughness: 0.1,
      metalness: 0.8,
      transmission: 0.5,
      transparent: true,
      opacity: 0.9,
      emissive: accentColor,
      emissiveIntensity: 0.4
    });

    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.2, 1), coreMat);
    group.add(core);

    const ringGeo = new THREE.TorusGeometry(1.8, 0.05, 16, 64);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const r1 = new THREE.Mesh(ringGeo, ringMat);
    const r2 = new THREE.Mesh(ringGeo, ringMat);
    r2.rotateX(Math.PI / 2);
    group.add(r1, r2);

    group.scale.set(0.8, 0.8, 0.8);
    return group;
  }
}
