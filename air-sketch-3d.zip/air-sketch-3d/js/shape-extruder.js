/**
 * Designed by Animesh_D
 * ShapeExtruder - Converts 2D air strokes directly into 3D Three.js meshes
 * Supports ExtrudeGeometry (beveled silhouettes), LatheGeometry (rotational solids),
 * and TubeGeometry (3D glowing neon curves).
 */
export class ShapeExtruder {
  /**
   * Build 3D mesh directly from the user's 2D drawing strokes
   */
  static generateFromStrokes(strokeData, options = {}) {
    const THREE = window.THREE;
    if (!THREE) {
      console.error('Three.js is not loaded');
      return null;
    }

    const { strokes, bounds, primaryColor } = strokeData;
    if (!strokes || strokes.length === 0) return null;

    const group = new THREE.Group();
    group.name = 'AirSketchExtrusion';

    const hexColor = parseInt(primaryColor.replace('#', '0x'), 16) || 0x00f0ff;

    // Determine if the sketch looks like a rotational profile (e.g. mug, vase, bottle)
    const isRotational = Boolean(options.forceLathe);

    if (isRotational && strokes.length > 0) {
      const latheMesh = this._createLatheMesh(THREE, strokes[0].points, hexColor);
      if (latheMesh) {
        group.add(latheMesh);
        return group;
      }
    }

    // Process each stroke
    strokes.forEach((stroke, index) => {
      const pts = stroke.points;
      if (pts.length < 3) return;

      const strokeHex = parseInt(stroke.color.replace('#', '0x'), 16) || hexColor;

      // Check if stroke forms a closed loop (start and end points close together)
      const startPt = pts[0];
      const endPt = pts[pts.length - 1];
      const loopDist = Math.hypot(startPt.x - endPt.x, startPt.y - endPt.y);
      const isClosedLoop = loopDist < 0.12 && pts.length > 8;

      if (isClosedLoop) {
        // Create beveled extruded 3D volume
        const extruded = this._createExtrudedShape(THREE, pts, bounds, strokeHex, index);
        if (extruded) group.add(extruded);
      } else {
        // Create 3D volumetric glowing tube
        const tube = this._createTubeStroke(THREE, pts, bounds, strokeHex, stroke.lineWidth);
        if (tube) group.add(tube);
      }
    });

    // If no meshes were added, generate fallback tube
    if (group.children.length === 0 && strokes[0]) {
      const fallbackTube = this._createTubeStroke(THREE, strokes[0].points, bounds, hexColor, 6);
      if (fallbackTube) group.add(fallbackTube);
    }

    return group;
  }

  static _createExtrudedShape(THREE, points, bounds, colorHex, index = 0) {
    try {
      const shape = new THREE.Shape();
      const scale = 4.0;

      // Center and scale coordinates
      const mapped = points.map((p) => ({
        x: (p.x - bounds.centerX) * scale,
        y: (bounds.centerY - p.y) * scale // Flip Y for 3D coordinate space
      }));

      shape.moveTo(mapped[0].x, mapped[0].y);
      for (let i = 1; i < mapped.length; i++) {
        shape.lineTo(mapped[i].x, mapped[i].y);
      }
      shape.closePath();

      const extrudeSettings = {
        steps: 2,
        depth: 0.4 + index * 0.1,
        bevelEnabled: true,
        bevelThickness: 0.12,
        bevelSize: 0.08,
        bevelOffset: 0,
        bevelSegments: 4
      };

      const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      geometry.center();

      // Holographic glowing cyber material
      const material = new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.2,
        metalness: 0.7,
        emissive: colorHex,
        emissiveIntensity: 0.35,
        side: THREE.DoubleSide
      });

      const mesh = new THREE.Mesh(geometry, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      // Add wireframe cage overlay
      const wireGeo = new THREE.WireframeGeometry(geometry);
      const wireMat = new THREE.LineBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.25
      });
      const wire = new THREE.LineSegments(wireGeo, wireMat);
      mesh.add(wire);

      return mesh;
    } catch (e) {
      console.warn('Extrude generation error:', e);
      return null;
    }
  }

  static _createTubeStroke(THREE, points, bounds, colorHex, lineWidth = 6) {
    try {
      const scale = 4.0;
      // Resample and smooth into 3D points
      const vPoints = points.map((p, idx) => {
        // Give subtle 3D depth curvature along the stroke
        const depthCurve = Math.sin((idx / points.length) * Math.PI) * 0.15;
        return new THREE.Vector3(
          (p.x - bounds.centerX) * scale,
          (bounds.centerY - p.y) * scale,
          depthCurve
        );
      });

      if (vPoints.length < 2) return null;

      const curve = new THREE.CatmullRomCurve3(vPoints);
      const radius = (lineWidth / 6) * 0.06;
      const geometry = new THREE.TubeGeometry(curve, Math.min(64, points.length * 2), radius, 8, false);

      const material = new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.1,
        metalness: 0.8,
        emissive: colorHex,
        emissiveIntensity: 0.6
      });

      const mesh = new THREE.Mesh(geometry, material);
      mesh.castShadow = true;
      return mesh;
    } catch (e) {
      console.warn('Tube generation error:', e);
      return null;
    }
  }

  static _createLatheMesh(THREE, points, colorHex) {
    try {
      const v2Points = [];
      const scale = 3.5;
      const sortedPts = [...points].sort((a, b) => a.y - b.y);

      sortedPts.forEach((p) => {
        // X is radius from vertical axis, Y is height
        const radius = Math.max(0.1, Math.abs(p.x - 0.5) * scale);
        const height = (0.5 - p.y) * scale;
        v2Points.push(new THREE.Vector2(radius, height));
      });

      if (v2Points.length < 3) return null;

      const geometry = new THREE.LatheGeometry(v2Points, 32);
      geometry.computeVertexNormals();

      const material = new THREE.MeshPhysicalMaterial({
        color: colorHex,
        roughness: 0.15,
        metalness: 0.3,
        transmission: 0.6, // Glassy translucent feel
        ior: 1.5,
        transparent: true,
        opacity: 0.9,
        emissive: colorHex,
        emissiveIntensity: 0.25,
        side: THREE.DoubleSide
      });

      const mesh = new THREE.Mesh(geometry, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      return mesh;
    } catch (e) {
      console.warn('Lathe generation error:', e);
      return null;
    }
  }
}
