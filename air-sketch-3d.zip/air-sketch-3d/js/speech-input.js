/**
 * Designed by Animesh_D
 * SpeechInput - Web Speech API voice capture with visual feedback,
 * microphone permission handling, and instant text fallback tags.
 */
export class SpeechInput {
  constructor(options = {}) {
    this.recognition = null;
    this.isListening = false;
    this.isSupported = false;
    this.transcript = '';

    // Callbacks
    this.onStart = options.onStart || null;
    this.onResult = options.onResult || null;
    this.onEnd = options.onEnd || null;
    this.onError = options.onError || null;

    this._initRecognition();
  }

  _initRecognition() {
    const SpeechClass = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechClass) {
      this.isSupported = true;
      try {
        this.recognition = new SpeechClass();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';

        this.recognition.onstart = () => {
          this.isListening = true;
          if (this.onStart) this.onStart();
        };

        this.recognition.onresult = (event) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            } else {
              interimTranscript += event.results[i][0].transcript;
            }
          }

          const currentText = finalTranscript || interimTranscript;
          this.transcript = currentText;
          if (this.onResult) {
            this.onResult(currentText, Boolean(finalTranscript));
          }
        };

        this.recognition.onerror = (event) => {
          this.isListening = false;
          let msg = 'Speech recognition error';
          if (event.error === 'not-allowed') {
            msg = 'Microphone permission denied. You can type what you drew in the text box below!';
          } else if (event.error === 'no-speech') {
            msg = 'No speech detected. Please speak clearly or type below.';
          } else {
            msg = `Speech error: ${event.error}`;
          }
          if (this.onError) this.onError(msg, event);
        };

        this.recognition.onend = () => {
          this.isListening = false;
          if (this.onEnd) this.onEnd(this.transcript);
        };
      } catch (err) {
        this.isSupported = false;
        console.warn('Speech recognition init failed:', err);
      }
    } else {
      this.isSupported = false;
    }
  }

  start() {
    if (!this.isSupported || !this.recognition) {
      if (this.onError) {
        this.onError('Speech recognition not supported in this browser. Please type your description.');
      }
      return false;
    }

    if (this.isListening) {
      this.stop();
      return false;
    }

    try {
      this.transcript = '';
      this.recognition.start();
      return true;
    } catch (err) {
      console.warn('Recognition start failed:', err);
      return false;
    }
  }

  stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {
        // Ignored
      }
      this.isListening = false;
    }
  }

  getQuickTags() {
    return [
      { label: '☕ Coffee Mug', value: 'a coffee mug' },
      { label: '🏎️ Sports Car', value: 'a futuristic sports car' },
      { label: '🚀 Spaceship', value: 'a sci-fi spaceship' },
      { label: '⚔️ Cyber Blade', value: 'a futuristic sword' },
      { label: '💎 Ring', value: 'a diamond ring' },
      { label: '🐱 Cute Cat', value: 'a cute cat' },
      { label: '🌳 Magic Tree', value: 'a magical tree' },
      { label: '🏺 Crystal Vase', value: 'a crystal vase' },
      { label: '💖 Neon Heart', value: 'a glowing heart' },
      { label: '⭐ Cosmic Star', value: 'a cosmic star' },
      { label: '✈️ Jet Plane', value: 'a jet airplane' },
      { label: '🪐 Ringed Planet', value: 'a ringed planet' }
    ];
  }
}
