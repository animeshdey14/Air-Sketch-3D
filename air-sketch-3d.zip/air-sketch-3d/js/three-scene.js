/**
 * Designed by Animesh_D
 * ThreeScene - WebGL 3D AR viewport overlaying the camera feed with OrbitControls,
 * lighting, holographic spawn animations, wireframe toggles, and interaction controls.
 */
export class ThreeScene {
  constructor(canvasElement, options = {}) {
    this.canvas = canvasElement;
    this.audio = options.audio || null;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.currentModel = null;

    this.isAutoRotating = true;
    this.isWireframe = false;
    this.showGrid = true;
    this.grid = null;

    this.spawnAnimation = {
      active: false,
      startTime: 0,
      duration: 1200 // ms
    };

    this.animFrameId = null;
    this._init();
  }

  _init() {
    const THREE = window.THREE;
    if (!THREE) {
      console.error('Three.js not loaded');
      return;
    }

    // 1. Scene with transparent background to see camera
    this.scene = new THREE.Scene();

    // 2. Camera with guaranteed valid dimensions
    const width = this.canvas.clientWidth || window.innerWidth || 800;
    const height = this.canvas.clientHeight || window.innerHeight || 600;
    const aspect = width / height;
    this.camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    this.camera.position.set(0, 1.2, 5.5);

    // 3. WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 4. Lighting setup
    this._setupLighting(THREE);

    // 5. Holographic Grid Floor
    this._setupGrid(THREE);

    // 6. OrbitControls
    if (window.THREE.OrbitControls) {
      this.controls = new window.THREE.OrbitControls(this.camera, this.canvas);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.08;
      this.controls.minDistance = 1.5;
      this.controls.maxDistance = 15;
      this.controls.target.set(0, 0, 0);
    }

    // 7. Start render loop
    this._animate();
  }

  _setupLighting(THREE) {
    // Ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    // Main Key Light
    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(4, 8, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    this.scene.add(keyLight);

    // Cyber Rim Light (Cyan)
    const rimLight = new THREE.DirectionalLight(0x00f0ff, 0.9);
    rimLight.position.set(-5, -2, -4);
    this.scene.add(rimLight);

    // Accent Fill Light (Magenta)
    const fillLight = new THREE.PointLight(0xff00aa, 0.8, 10);
    fillLight.position.set(0, -3, 3);
    this.scene.add(fillLight);
  }

  _setupGrid(THREE) {
    // Holographic cyber grid hovering in mid-air
    const size = 10;
    const divisions = 20;
    this.grid = new THREE.GridHelper(size, divisions, 0x00f0ff, 0x003344);
    this.grid.position.y = -1.6;
    this.grid.material.transparent = true;
    this.grid.material.opacity = 0.45;
    this.scene.add(this.grid);
  }

  displayModel(meshGroup) {
    if (!meshGroup) return;
    const THREE = window.THREE;

    // Ensure viewport is full screen and rendered correctly
    const width = window.innerWidth;
    const height = window.innerHeight;
    this.resize(width, height);

    // Remove existing model
    if (this.currentModel) {
      this.scene.remove(this.currentModel);
      this._disposeObject(this.currentModel);
      this.currentModel = null;
    }

    this.currentModel = meshGroup;

    // Center and calculate bounding box
    const box = new THREE.Box3().setFromObject(this.currentModel);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());

    // Re-center model at origin
    this.currentModel.position.x = -center.x;
    this.currentModel.position.y = -center.y;
    this.currentModel.position.z = -center.z;

    // Wrap in parent anchor for easy manipulation and spawn animation
    const anchorGroup = new THREE.Group();
    anchorGroup.name = 'ModelAnchor';
    anchorGroup.add(this.currentModel);
    this.scene.add(anchorGroup);
    this.currentModel = anchorGroup;

    // Normalize scale to fit nicely in view
    const maxDim = Math.max(size.x, size.y, size.z) || 1;
    const targetScale = 2.4 / maxDim;
    this.currentModel.userData.targetScale = targetScale;
    this.currentModel.scale.set(targetScale, targetScale, targetScale);

    // Adjust grid position right below the model
    if (this.grid) {
      this.grid.position.y = - (size.y * targetScale) / 2 - 0.2;
    }

    // Camera view setup
    this.camera.position.set(0, 1.2, 5.2);
    if (this.controls) {
      this.controls.target.set(0, 0, 0);
      this.controls.update();
    }

    // Trigger futuristic materialize spawn animation
    this.spawnAnimation.active = true;
    this.spawnAnimation.startTime = performance.now();

    if (this.audio) {
      this.audio.playMaterialize();
    }

    // Render immediately
    this.renderer.render(this.scene, this.camera);
  }

  applyTwoHandTransform({ deltaDist, deltaAngle, deltaMidX, deltaMidY, bothPinching }) {
    if (!this.currentModel) return;

    // Pause auto turntable while user is interacting with hands
    this.isAutoRotating = false;

    // 1. Zoom / Scale (Moving hands apart = Zoom In, Bringing hands together = Zoom Out)
    if (Math.abs(deltaDist) > 0.001) {
      const zoomSpeed = 3.5;
      const factor = 1.0 + deltaDist * zoomSpeed;
      const curS = this.currentModel.scale.x;
      const baseS = this.currentModel.userData.targetScale || 1.0;
      const newS = Math.max(baseS * 0.25, Math.min(baseS * 4.5, curS * factor));
      this.currentModel.scale.set(newS, newS, newS);
    }

    // 2. Rotate Z (Roll / steering wheel gesture)
    if (Math.abs(deltaAngle) > 0.003) {
      this.currentModel.rotation.z += deltaAngle * 1.8;
    }

    // 3. Rotate Y (Yaw / horizontal turntable rotation)
    if (Math.abs(deltaMidX) > 0.001) {
      this.currentModel.rotation.y += deltaMidX * 5.0;
    }

    // 4. Rotate X (Pitch / vertical tilt)
    if (Math.abs(deltaMidY) > 0.001) {
      this.currentModel.rotation.x += deltaMidY * 5.0;
    }

    // 5. Position / Pan (Move hologram in AR camera space if both hands pinch)
    if (bothPinching) {
      this.currentModel.position.x += deltaMidX * 6.0;
      this.currentModel.position.y -= deltaMidY * 6.0;
    }

    // Render immediately
    this.renderer.render(this.scene, this.camera);
  }

  applySingleHandRotate(deltaX, deltaY) {
    if (!this.currentModel) return;
    this.isAutoRotating = false;
    this.currentModel.rotation.y += deltaX * 4.5;
    this.currentModel.rotation.x += deltaY * 4.5;
    this.renderer.render(this.scene, this.camera);
  }

  cycleMaterialMode() {
    this.materialModeIndex = ((this.materialModeIndex || 0) + 1) % 3;
    const modes = ['Solid PBR', 'Neon Wireframe', 'Holo X-Ray'];
    const currentMode = modes[this.materialModeIndex];

    if (!this.currentModel) return currentMode;

    this.currentModel.traverse((child) => {
      if (child.isMesh && child.material) {
        const mats = Array.isArray(child.material) ? child.material : [child.material];
        mats.forEach((m) => {
          if (this.materialModeIndex === 0) {
            // Solid PBR
            m.wireframe = false;
            m.transparent = false;
            m.opacity = 1.0;
            if (m.transmission !== undefined) m.transmission = 0;
          } else if (this.materialModeIndex === 1) {
            // Neon Wireframe
            m.wireframe = true;
            m.transparent = true;
            m.opacity = 0.85;
          } else if (this.materialModeIndex === 2) {
            // Holo X-Ray Translucent
            m.wireframe = false;
            m.transparent = true;
            m.opacity = 0.45;
            if (m.transmission !== undefined) m.transmission = 0.7;
          }
          m.needsUpdate = true;
        });
      }
    });

    this.renderer.render(this.scene, this.camera);
    return currentMode;
  }

  toggleAutoRotate() {
    this.isAutoRotating = !this.isAutoRotating;
    return this.isAutoRotating;
  }

  toggleWireframe() {
    return this.cycleMaterialMode();
  }

  toggleGrid() {
    this.showGrid = !this.showGrid;
    if (this.grid) {
      this.grid.visible = this.showGrid;
    }
    return this.showGrid;
  }

  resetView() {
    if (this.currentModel) {
      const baseS = this.currentModel.userData.targetScale || 1.0;
      this.currentModel.scale.set(baseS, baseS, baseS);
      this.currentModel.rotation.set(0, 0, 0);
      this.currentModel.position.set(0, 0, 0);
    }
    if (this.controls) {
      this.camera.position.set(0, 1.2, 5.2);
      this.controls.target.set(0, 0, 0);
      this.controls.update();
    }
    this.renderer.render(this.scene, this.camera);
  }

  changeModelColor(hexColor) {
    if (!this.currentModel) return;
    const THREE = window.THREE;
    const col = new THREE.Color(hexColor);

    this.currentModel.traverse((child) => {
      if (child.isMesh && child.material) {
        if (child.material.color) {
          child.material.color = col;
        }
        if (child.material.emissive) {
          child.material.emissive = col;
        }
      }
    });
  }

  resize(width, height) {
    if (!this.renderer || !this.camera) return;
    this.camera.aspect = width / (height || 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  _animate() {
    this.animFrameId = requestAnimationFrame(() => this._animate());

    const now = performance.now();

    // Spawn materialize easing animation
    if (this.spawnAnimation.active && this.currentModel) {
      const elapsed = now - this.spawnAnimation.startTime;
      const progress = Math.min(1.0, elapsed / this.spawnAnimation.duration);
      // Cubic ease-out
      const ease = 1 - Math.pow(1 - progress, 3);
      const targetS = this.currentModel.userData.targetScale || 1.0;
      const currentS = targetS * ease;
      this.currentModel.scale.set(currentS, currentS, currentS);

      // Spin slightly during materialize
      this.currentModel.rotation.y = (1 - ease) * Math.PI * 2;

      if (progress >= 1.0) {
        this.spawnAnimation.active = false;
      }
    } else if (this.isAutoRotating && this.currentModel) {
      // Gentle continuous turntable rotation
      this.currentModel.rotation.y += 0.008;
    }

    if (this.controls) {
      this.controls.update();
    }

    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  }

  _disposeObject(obj) {
    obj.traverse((child) => {
      if (child.isMesh) {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          if (Array.isArray(child.material)) {
            child.material.forEach((m) => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      }
    });
  }

  destroy() {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    if (this.currentModel) this._disposeObject(this.currentModel);
    if (this.renderer) this.renderer.dispose();
  }
}
