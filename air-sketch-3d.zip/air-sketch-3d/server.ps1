# Designed by Animesh_D
<#
.SYNOPSIS
  Air Sketch 3D Local Development Server - Designed by Animesh_D
  Serves static files with correct MIME types and CORS on http://localhost:8080
#>

param(
  [int]$Port = 8080
)

$listener = New-Object System.Net.HttpListener
$prefix = "http://localhost:$Port/"
$listener.Prefixes.Add($prefix)

try {
  $listener.Start()
  Write-Host "=================================================" -ForegroundColor Cyan
  Write-Host "  Air Sketch 3D Local Server - Designed by Animesh_D" -ForegroundColor Green
  Write-Host "  Open in your browser: $prefix" -ForegroundColor Yellow
  Write-Host "  Press Ctrl+C to stop server." -ForegroundColor Gray
  Write-Host "=================================================" -ForegroundColor Cyan

  $mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".mjs"  = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".wasm" = "application/wasm"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".obj"  = "text/plain"
    ".gltf" = "model/gltf+json"
    ".glb"  = "model/gltf-binary"
  }

  $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

  while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    $localPath = $request.Url.LocalPath.TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($localPath)) {
      $localPath = "index.html"
    }

    $filePath = Join-Path $scriptDir $localPath

    # Prevent directory traversal
    $fullPath = [System.IO.Path]::GetFullPath($filePath)
    if (-not $fullPath.StartsWith([System.IO.Path]::GetFullPath($scriptDir))) {
      $response.StatusCode = 403
      $response.Close()
      continue
    }

    if (Test-Path $filePath -PathType Leaf) {
      $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
      $contentType = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }

      $response.ContentType = $contentType
      $response.Headers.Add("Access-Control-Allow-Origin", "*")
      $response.Headers.Add("Cache-Control", "no-cache")

      $bytes = [System.IO.File]::ReadAllBytes($filePath)
      $response.ContentLength64 = $bytes.Length
      $response.OutputStream.Write($bytes, 0, $bytes.Length)
      $response.StatusCode = 200
    } else {
      $response.StatusCode = 404
      $notFoundBytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $localPath")
      $response.OutputStream.Write($notFoundBytes, 0, $notFoundBytes.Length)
    }

    $response.Close()
  }
} catch {
  Write-Host "Server stopped or error: $_" -ForegroundColor Red
} finally {
  $listener.Stop()
}
