:: Designed by Animesh_D
@echo off
title Air Sketch 3D - Designed by Animesh_D
cd /d "%~dp0"

echo ========================================================
echo       Launching Air Sketch 3D - Designed by Animesh_D
echo ========================================================
echo.
echo Opening http://localhost:8080 in your browser...
start http://localhost:8080

echo Starting local web server on port 8080...
powershell -ExecutionPolicy Bypass -NoProfile -File .\server.ps1 -Port 8080

pause
